/**
 * Automated Verification Script for Drixvid Support AI
 * Tests all 10 core evaluation scenarios
 */

const BASE_URL = 'http://localhost:3000';

async function runTests() {
  console.log('--- Starting Drixvid Support AI Test Suite ---\n');
  let passed = 0;
  let failed = 0;

  async function assertTest(name, fn) {
    process.stdout.write(`Testing: ${name}... `);
    try {
      await fn();
      console.log('✅ PASS');
      passed++;
    } catch (e) {
      console.log('❌ FAIL:', e.message);
      failed++;
    }
  }

  // 1. Health & Config
  await assertTest('1. System Health & Configuration Endpoints', async () => {
    const res = await fetch(`${BASE_URL}/api/health`);
    if (!res.ok) throw new Error(`Health status ${res.status}`);
    const data = await res.json();
    if (data.status !== 'ok') throw new Error('Health status is not ok');
    if (typeof data.knowledgeArticlesCount !== 'number') throw new Error('Missing knowledge base count');
  });

  // 2. Normal Text Question
  await assertTest('2. Normal Text Troubleshooting Question (Playback 4028)', async () => {
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{ role: 'user', content: 'Why does my video keep buffering on Error 4028?' }],
        category: 'playback',
        language: 'en',
      }),
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.reply || !data.reply.includes('4028')) throw new Error('Response did not address error 4028');
    if (!data.hasVerificationButtons) throw new Error('Missing verification question');
  });

  // 3. Multi-turn Follow-up Context
  await assertTest('3. Follow-up Question Using Previous Conversation Context', async () => {
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [
          { role: 'user', content: 'Video shows black screen on startup' },
          { role: 'assistant', content: 'Please force close and check available storage.' },
          { role: 'user', content: 'I have 2GB free storage, but now it shows WebGL context lost error' }
        ],
        category: 'crashes',
        language: 'en',
      }),
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.reply) throw new Error('Missing follow-up reply');
  });

  // 4. Screenshot / Image Question
  await assertTest('4. Screenshot Image Troubleshooting', async () => {
    const sampleSvgBase64 = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><text y="20">ERROR 4028</text></svg>').toString('base64');
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{
          role: 'user',
          content: 'Here is my screenshot showing error 4028',
          image: { dataUrl: sampleSvgBase64, mimeType: 'image/svg+xml' }
        }],
        category: 'playback',
      }),
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.reply) throw new Error('Missing image reply');
  });

  // 5. Invalid / Oversized Image Format Validation
  await assertTest('5. Invalid Image Format Rejection (MIME Validation)', async () => {
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{
          role: 'user',
          content: 'Test',
          image: { dataUrl: 'data:application/pdf;base64,xxxx', mimeType: 'application/pdf' }
        }],
      }),
    });
    if (res.status !== 400) throw new Error(`Expected HTTP 400, got ${res.status}`);
  });

  // 6. Rate Limiting Check
  await assertTest('6. Rate Limit Protection Check', async () => {
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-forwarded-for': '198.51.100.42' },
      body: JSON.stringify({ messages: [{ role: 'user', content: 'Ping' }] }),
    });
    if (!res.ok && res.status !== 429) throw new Error(`Unexpected status ${res.status}`);
  });

  // 7. Human Escalation Ticket Generation
  await assertTest('7. Human Escalation Support Ticket Dispatch', async () => {
    const res = await fetch(`${BASE_URL}/api/tickets`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        category: 'billing',
        userDescription: 'Charged twice on UPI but premium entitlement locked',
        userEmail: 'user@example.com',
      }),
    });
    if (res.status !== 201) throw new Error(`Expected 201, got ${res.status}`);
    const data = await res.json();
    if (!data.ticket || !data.ticket.id.startsWith('DX-')) throw new Error('Invalid ticket ID format');
    if (!data.gmailComposeUrl.includes('drixvidofficial@gmail.com') && !data.gmailComposeUrl.includes('drixvidofficial%40gmail.com')) throw new Error('Invalid Gmail escalation recipient');
  });

  // 8. Auto-training & Learned Solutions
  await assertTest('8. Auto-Training Solution Pattern Recording', async () => {
    const res = await fetch(`${BASE_URL}/api/learn-solution`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        problem: 'Offline video segment stuttering',
        solution: 'Tap Repair Download Vault in Settings',
        category: 'library',
      }),
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.success || !data.pattern) throw new Error('Pattern not recorded');
  });

  // 9. Unrelated Question Filtering
  await assertTest('9. Unrelated Off-Topic Query Filtering', async () => {
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{ role: 'user', content: 'What is the recipe for chocolate cake?' }],
        category: 'general',
      }),
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.reply.includes('Drixvid')) throw new Error('Did not enforce Drixvid specialization boundary');
  });

  // 10. Hindi Localization Check
  await assertTest('10. Hindi Language Localization Response', async () => {
    const res = await fetch(`${BASE_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: [{ role: 'user', content: 'Mera video play nahi ho raha 4028 error hai' }],
        category: 'playback',
        language: 'hi',
      }),
    });
    if (!res.ok) throw new Error(`Status ${res.status}`);
    const data = await res.json();
    if (!data.reply || !/[\u0900-\u097F]/.test(data.reply)) throw new Error('Response does not contain Devanagari Hindi text');
  });

  console.log(`\n--- Test Summary: ${passed} Passed, ${failed} Failed ---`);
  if (failed > 0) process.exit(1);
}

runTests().catch((e) => {
  console.error('Fatal test error:', e);
  process.exit(1);
});
