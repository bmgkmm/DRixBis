# Prompt for Gemini AI Studio — Finish the Drixvid Support AI Project

You are acting as a senior full-stack engineer, AI engineer, security engineer, and QA engineer. I am providing the complete Drixvid Support AI source project. Work directly on these files; do not merely give me a tutorial or isolated code snippets.

## Goal
Turn this exact project into a working Drixvid-specific support assistant integrated with the existing interface. Preserve the app's current design, routes, components, and branding. Do not replace it with a generic chatbot.

## Required work
1. Inspect every source file and dependency before editing. Use `support-knowledge-base.ts` as a starting point, and verify its claims against the supplied Drixvid app source. Do not invent menus, features, error codes, app versions, service health, or support response-time promises.
2. Complete the Express `/api/chat` integration for OpenAI Responses API and optional Gemini provider. Keep provider keys on the server only. Validate model availability and image support, use timeouts, rate limits, safe errors, and bounded conversation/image payloads.
3. Make image/screenshot analysis work with a vision-capable model. Report only visible evidence and distinguish hypotheses from facts. If no key is configured, clearly show offline mode instead of pretending to analyze an image.
4. Use the reviewed source-derived knowledge base to ground answers. Do not treat a user's “problem solved” click as model training. Knowledge changes must be reviewed and authenticated.
5. Preserve privacy. Do not expose support tickets to other users. Keep Firestore rules deny-by-default until authenticated owner-scoped access is implemented. Do not weaken security rules to make a demo appear to work.
6. Keep ticket/email behavior honest: creating a ticket or Gmail compose draft does not send an email automatically. Only report email delivery after a real mail provider confirms delivery.
7. Make the diagnostic panel show only real browser/server observations. Never show CDN, payments, Firebase, or other services as “operational” unless the system actually checks them.
8. Fix TypeScript, React, dependency, runtime, mobile layout, and accessibility errors found during testing. Do not remove working features or alter unrelated screens.

## Mandatory verification
- Install dependencies and report the actual result.
- Run `npm run build` and `npm run lint`.
- Start the app and test `/api/health`, `/api/ai/status`, text chat, follow-up context, screenshot input, missing key, invalid key, quota/rate limit, timeout, and ticket creation.
- Test at least one real API request only when a valid key and active API quota are configured. Never fabricate test success.
- If an external credential, billing/quota, Firebase project setting, or deployment secret is missing, finish all possible offline work and list exactly what remains. Do not put secrets into frontend code or the ZIP.

## Deliverables
Return the complete updated project as a downloadable ZIP with all required source/configuration files, `.env.example`, updated README, build/test results, and concise setup instructions. Ensure the project files are at the ZIP root, not buried in an unexpected nested directory. Do not claim production-ready or fully working until the build and real integration tests have actually passed.
