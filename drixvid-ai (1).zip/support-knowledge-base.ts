/**
 * DrixVid support knowledge base.
 * Facts below were extracted from the supplied DrixVid source project (React/Firebase).
 * Do not treat this as live telemetry or assume that configured external services are healthy.
 */
export interface SupportKnowledgeEntry {
  id: string;
  title: string;
  keywords: string[];
  facts: string[];
  safeChecks: string[];
}

export const supportKnowledgeBase: SupportKnowledgeEntry[] = [
  {
    id: 'auth-firebase', title: 'Sign-in, sign-up, and account access',
    keywords: ['login','sign in','signin','signup','sign up','google','email','password','forgot','reset','verification','verify email','otp','account','firebase auth','लॉगिन','पासवर्ड','खाता','ओटीपी','ईमेल'],
    facts: ['The supplied app uses Firebase Authentication. The UI includes email/password sign-in, account creation, Google sign-in, email verification, password reset, and a six-digit OTP screen. The server source includes /api/auth/request-otp and /api/auth/verify-otp routes.', 'A successful UI action does not prove Firebase project settings, email delivery, authorized domains, or server-side OTP configuration are correct.'],
    safeChecks: ['Check the exact on-screen error and whether it appears before or after submitting the form.', 'Confirm the device has a working connection and the app is using the intended Firebase project.', 'For password issues, use the app password-reset flow; never share a password, OTP, or recovery code.']
  },
  {
    id: 'firebase-profile', title: 'Profile and Firestore synchronization',
    keywords: ['profile','display name','avatar','sync','firestore','permission denied','users collection','firebase','save profile','प्रोफाइल','सिंक'],
    facts: ['The supplied app syncs user profile fields to a Firestore users/{uid} document, including uid, displayName, optional email/photo URL, and timestamps.', 'Firestore permission errors depend on deployed security rules and authenticated identity; source code alone cannot confirm deployed rules.'],
    safeChecks: ['Capture the exact Firestore error code and affected action.', 'Confirm the user is signed in to the expected Firebase project.', 'Review deployed Firestore rules before changing permissions; do not make collections public to fix a permission error.']
  },
  {
    id: 'playback-4028', title: 'Playback Error 4028 and Media Buffering',
    keywords: ['4028', 'error 4028', 'playback error 4028', 'buffering', 'buffer', 'media segment stall', '4028 error', 'बफर', 'एरर 4028'],
    facts: [
      'Error 4028 in DrixVid occurs when the video player encounters a media segment download stall or CDN buffer timeout.',
      'The DrixVid player buffer engine times out after 12 seconds of stalled chunk downloads, switching the video state to Error 4028.',
      'Network fluctuations, high-resolution stream drops, or browser media buffer memory exhaustion are primary causes.'
    ],
    safeChecks: [
      'Check if switching video quality from Auto/1080p to 480p or 720p resolves the Error 4028 buffer stall.',
      'Test your network connectivity by toggling Wi-Fi or testing another video stream in the feed.',
      'Clear the browser tab media cache or reload the player to release allocated WebGL/HTML5 video memory buffers.',
      'If Error 4028 persists across all videos, escalate to Drixvid Technical Support for CDN endpoint diagnostics.'
    ]
  },
  {
    id: 'video-feed', title: 'Video feed, playback, and categories',
    keywords: ['video','playback','player','play','buffer','buffering','black screen','quality','resolution','feed','category','search','autoplay','audio','sound','4028','वीडियो','प्ले','बफर','आवाज','क्वालिटी'],
    facts: ['The supplied app has a home/feed experience, search and category selection, video watch view, quality preference, and autoplay-next preference. The source includes sample video URLs, so a particular video URL or external media host can fail independently of the UI.', 'The supplied source does not establish that a production CDN, streaming cache, DRM service, or payment API is deployed or healthy.'],
    safeChecks: ['Test another video and compare Wi-Fi with mobile data.', 'Record whether the player opens, starts then stalls, or shows an explicit error.', 'Try a lower quality only if the player actually exposes a quality control.', 'Do not claim a cache-clear or service repair is available unless the UI contains that control.']
  },
  {
    id: 'creator-upload', title: 'Creator Studio and uploads',
    keywords: ['upload','creator studio','publish','video file','thumbnail','upload failed','file too large','creator','अपलोड','वीडियो अपलोड'],
    facts: ['The supplied app source contains a Creator Studio and an upload-success callback that adds a video to the client application state. This does not by itself confirm that a production media-storage pipeline or durable upload backend is configured.'],
    safeChecks: ['Ask whether the upload fails during file selection, progress, or after submitting.', 'Check file type, file size, connection stability, and the exact error text.', 'Do not promise a video is permanently stored unless the app confirms a successful backend upload.']
  },
  {
    id: 'channels-social', title: 'Channels, subscriptions, likes, comments, and playlists',
    keywords: ['channel','subscribe','subscription channel','like','dislike','comment','playlist','watch later','history','shorts','reels','follow','चैनल','लाइक','कमेंट','प्लेलिस्ट'],
    facts: ['The supplied app source includes channel selection, subscribe toggles, like/dislike toggles, watch-later and history IDs, playlists, comments, and a Shorts feed. Some of these states are managed in client-side React state; inspect persistence behavior before promising cross-device synchronization.'],
    safeChecks: ['Identify the specific action and whether it fails immediately or disappears after refresh.', 'Try refreshing once and check whether the state persists.', 'If data disappears after reload, determine whether a backend write is implemented for that feature.']
  },
  {
    id: 'settings-ui', title: 'Theme, accessibility, and playback settings',
    keywords: ['settings','theme','dark mode','light mode','quality','autoplay','language','voice','speech','microphone','permission','सेटिंग','डार्क मोड','माइक'],
    facts: ['The supplied app includes auto/dark/light theme preferences, video quality selection, autoplay-next, voice input using browser SpeechRecognition when supported, and read-aloud using SpeechSynthesis. Browser and device support can differ.'],
    safeChecks: ['Check whether the browser/device supports the feature and has the required permission.', 'For microphone issues, verify browser permission and whether speech recognition is supported.', 'Change one preference at a time and reload to test persistence.']
  },
  {
    id: 'admin-security', title: 'Admin access and security',
    keywords: ['admin','administrator','permission','unauthorized','access denied','role','security','rules','admin panel','एडमिन','अनुमति'],
    facts: ['The supplied app has an admin route/panel and client-side admin-related state. Client-side visibility or local storage is not sufficient authorization for privileged operations.', 'Never ask a user to expose secrets or weaken Firebase rules. Admin access must be verified by trusted server-side authorization or strict Firestore rules.'],
    safeChecks: ['Record the exact route and permission error.', 'Confirm the signed-in account and its server-verified role.', 'Review Firebase rules and privileged server routes before changing access.']
  },
  {
    id: 'support-ai', title: 'Drixvid Support AI and API configuration',
    keywords: ['support ai','openai','chatgpt api','gemini','api key','quota','429','401','model not found','image analysis','screenshot','ai unavailable','एआई','स्क्रीनशॉट','एपीआई'],
    facts: ['The support project can call OpenAI Responses API from its Express server and optionally use Gemini when configured. API keys belong in server environment secrets, never in browser code.', 'A configured key is not proof that a request works. Actual API access depends on key validity, model availability, account quota/billing, and network connectivity.', 'Image diagnosis requires a vision-capable configured model and a successful request containing the image.'],
    safeChecks: ['Check the server-side provider status without printing secrets.', 'Use server logs to inspect the HTTP status code but redact credentials and personal data.', 'For 401/403 verify key and project permissions; for 429 check quota/rate limits; for model errors verify the configured model is available to that API project.', 'Never paste an API key into chat or expose it in frontend environment variables.']
  },
  {
    id: 'tickets-escalation', title: 'Support tickets and escalation',
    keywords: ['ticket','support agent','escalation','email support','human support','ticket status','टिकट','एजेंट','सपोर्ट'],
    facts: ['The supplied support assistant project can create a ticket record and generate a Gmail compose link. A compose link only prepares an email; it does not send the email automatically. In-memory ticket records may be lost when the server restarts unless a persistent database is configured.', 'Do not promise a live human agent, automatic email delivery, a response-time SLA, or cloud persistence unless a connected service confirms it.'],
    safeChecks: ['Verify the ticket ID shown by the app.', 'If email escalation is needed, open the prepared email and explicitly press Send.', 'For durable ticket tracking, configure and test a persistent backend and access controls.']
  },
];

const normalize = (s: string) => s.toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}\s-]/gu, ' ').split(/\s+/).filter(Boolean);

export function retrieveSupportKnowledge(query: string, maxEntries = 3): SupportKnowledgeEntry[] {
  const tokens = new Set(normalize(query));
  const scored = supportKnowledgeBase.map((entry) => {
    const text = [entry.title, ...entry.keywords, ...entry.facts].join(' ').toLowerCase();
    const keywords = new Set(normalize(text));
    let score = 0;
    for (const token of tokens) if (keywords.has(token)) score += token.length > 3 ? 2 : 1;
    for (const phrase of entry.keywords) if (phrase.length > 3 && query.toLowerCase().includes(phrase.toLowerCase())) score += 4;
    return { entry, score };
  }).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
  return scored.slice(0, maxEntries).map((x) => x.entry);
}
