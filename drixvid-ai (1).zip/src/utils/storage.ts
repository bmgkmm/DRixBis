import { ChatSession, SupportTicket } from '../types';

const STORAGE_KEYS = {
  CHAT_SESSIONS: 'drixvid_troubleshooting_sessions',
  APP_LANGUAGE: 'drixvid_app_language',
  DIAGNOSTIC_CONSENT: 'drixvid_diagnostic_consent',
  SUPPORT_TICKETS: 'drixvid_support_tickets',
};

export function getChatSessions(): ChatSession[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CHAT_SESSIONS);
    if (raw) return JSON.parse(raw);
    return [];
  } catch {
    return [];
  }
}

export function saveChatSession(session: ChatSession): void {
  try {
    const current = getChatSessions().filter((s) => s.id !== session.id);
    const updated = [session, ...current].slice(0, 30);
    localStorage.setItem(STORAGE_KEYS.CHAT_SESSIONS, JSON.stringify(updated));
  } catch {}
}

export function clearChatSessions(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.CHAT_SESSIONS);
  } catch {}
}

export function getLocalTickets(): SupportTicket[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SUPPORT_TICKETS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveLocalTicket(ticket: SupportTicket): SupportTicket[] {
  try {
    const current = getLocalTickets().filter((t) => t.id !== ticket.id);
    const updated = [ticket, ...current];
    localStorage.setItem(STORAGE_KEYS.SUPPORT_TICKETS, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

export function getDiagnosticConsent(): boolean {
  try {
    const val = localStorage.getItem(STORAGE_KEYS.DIAGNOSTIC_CONSENT);
    return val === null ? true : val === 'true'; // default to true with clear user control
  } catch {
    return true;
  }
}

export function setDiagnosticConsent(allowed: boolean): void {
  try {
    localStorage.setItem(STORAGE_KEYS.DIAGNOSTIC_CONSENT, String(allowed));
  } catch {}
}

export function getAppLanguage(): 'en' | 'hi' {
  try {
    const lang = localStorage.getItem(STORAGE_KEYS.APP_LANGUAGE);
    return lang === 'hi' ? 'hi' : 'en';
  } catch {
    return 'en';
  }
}

export function setAppLanguage(lang: 'en' | 'hi'): void {
  try {
    localStorage.setItem(STORAGE_KEYS.APP_LANGUAGE, lang);
  } catch {}
}
