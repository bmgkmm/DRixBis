import { SupportTicket } from '../types';

export interface EmailDispatchPayload {
  to: string;
  subject: string;
  bodyText: string;
  gmailComposeUrl: string;
  mailtoUrl: string;
}

export function generateGmailDispatch(ticket: SupportTicket): EmailDispatchPayload {
  const recipient = 'drixvidofficial@gmail.com';
  const subject = `[DRIXVID ESCALATION] Ticket #${ticket.id}: ${ticket.category.toUpperCase()} Unresolved Issue`;

  const bodyText = `Drixvid Technical Support Escalation Notice
==============================================
TICKET ID: ${ticket.id}
PRIORITY: ${ticket.priority.toUpperCase()}
CATEGORY: ${ticket.category.toUpperCase()}
DATE: ${ticket.createdAt}
USER CONTACT: ${ticket.contactEmail}

ISSUE DESCRIPTION:
----------------------------------------------
${ticket.userDescription}

TROUBLESHOOTING STEPS ALREADY ATTEMPTED:
----------------------------------------------
${
  ticket.attemptedSolutions.length > 0
    ? ticket.attemptedSolutions.map((s, i) => `${i + 1}. ${s}`).join('\n')
    : 'Automated initial step applied; user verified problem still exists.'
}

DIAGNOSTIC & TELEMETRY SNAPSHOT:
----------------------------------------------
${ticket.diagnosticSummary}
App Version: Not verified
Platform: Drixvid Web / Android Engine
CDN & Auth Status: Not checked by this ticket
Assigned Engineering: ${ticket.assignedTeam}

ACTION REQUIRED:
----------------------------------------------
1. Review ticket details in Drixvid Console.
2. Reply directly to customer at: ${ticket.contactEmail}

---
Prepared by Drixvid Support AI. This email has not been sent automatically.
`;

  const encodedSubject = encodeURIComponent(subject);
  const encodedBody = encodeURIComponent(bodyText);

  // Direct Gmail web compose link
  const gmailComposeUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${recipient}&su=${encodedSubject}&body=${encodedBody}`;

  // Standard mailto
  const mailtoUrl = `mailto:${recipient}?subject=${encodedSubject}&body=${encodedBody}`;

  return {
    to: recipient,
    subject,
    bodyText,
    gmailComposeUrl,
    mailtoUrl,
  };
}
