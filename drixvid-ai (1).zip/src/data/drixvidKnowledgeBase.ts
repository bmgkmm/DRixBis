/**
 * Drixvid App Verified Technical Knowledge Base
 * Extensible, versioned reference covering actual Drixvid app workflows,
 * features, error codes, and troubleshooting procedures.
 */

export interface KnowledgeArticle {
  id: string;
  category: 'playback' | 'account' | 'crashes' | 'billing' | 'library' | 'settings' | 'general';
  title: string;
  titleHi: string;
  keywords: string[];
  errorCode?: string;
  symptoms: string[];
  rootCause: string;
  rootCauseHi: string;
  steps: string[];
  stepsHi: string[];
  verificationQuestion: string;
  verificationQuestionHi: string;
  safeActionsOnly: boolean;
  requiresEscalationIfFails: boolean;
}

export const DRIXVID_KNOWLEDGE_BASE: KnowledgeArticle[] = [
  {
    id: 'kb-error-4028',
    category: 'playback',
    title: 'Error 4028: Video Stream Buffer Timeout (ERR_STREAM_BUFFER_TIMEOUT)',
    titleHi: 'एरर 4028: वीडियो स्ट्रीम बफर टाइमआउट',
    errorCode: '4028',
    keywords: ['4028', 'buffer', 'buffering', 'freeze', 'timeout', 'stream', 'black screen', 'video stuck', 'ruka', 'atak'],
    symptoms: [
      'Player displays spinning buffer wheel at timestamp',
      'Screen goes black with error code 4028: ERR_STREAM_BUFFER_TIMEOUT',
      'Audio cuts out or loops 1-2 seconds'
    ],
    rootCause: 'DRM stream socket connection dropped a segment chunk or local video buffer memory underrun.',
    rootCauseHi: 'DRM स्ट्रीम सॉकेट कनेक्शन में सेगमेंट छूट जाना या लोकल वीडियो बफर मेमोरी ओवरफ्लो।',
    steps: [
      'In the video player, tap the Gear icon and change video quality from 1080p AI to 720p or Auto.',
      'Go to Drixvid Settings > Storage and tap "Clear Streaming Cache" (this is safe and does not delete your downloaded videos).',
      'Toggle Airplane mode on your device for 5 seconds to force a fresh DNS and CDN edge node handshake.',
      'Resume playback. If the video was downloaded, tap "Repair Download Segment" in your Library.'
    ],
    stepsHi: [
      'वीडियो प्लेयर में गियर (सेटिंग्स) आइकन दबाएं और क्वालिटी को 1080p AI से 720p या Auto पर बदलें।',
      'Drixvid सेटिंग्स > स्टोरेज में जाकर "Clear Streaming Cache" पर टैप करें (यह सुरक्षित है और डाउनलोड डिलीट नहीं होंगे)।',
      'डिवाइस पर एयरप्लेन मोड को 5 सेकंड के लिए चालू और बंद करें ताकि नेटवर्क सॉकेट रीफ्रेश हो जाए।',
      'वीडियो दोबारा चलाएं। यदि यह डाउनलोड वीडियो था, तो लाइब्रेरी में "Repair Download Segment" दबाएं।'
    ],
    verificationQuestion: 'Did changing the stream quality or clearing cache resume smooth playback?',
    verificationQuestionHi: 'क्या क्वालिटी बदलने या कैश क्लियर करने से वीडियो सुचारू रूप से चलने लगा?',
    safeActionsOnly: true,
    requiresEscalationIfFails: true,
  },
  {
    id: 'kb-auth-401',
    category: 'account',
    title: 'Auth Error 401: Token Handshake Dropped / Expired',
    titleHi: 'ऑथ एरर 401: टोकन हैंडशेक ड्रॉप या सेशन एक्सपायर',
    errorCode: '401',
    keywords: ['401', 'login', 'signin', 'token', 'auth', 'handshake', 'expired', 'password', 'otp', 'sign in', 'log in'],
    symptoms: [
      'Dialog displays [AUTH_ERR_401]: OAuth Token Handshake Dropped',
      'Redirected back to Sign In screen repeatedly',
      'Email login link fails to authenticate session'
    ],
    rootCause: 'Local OAuth session token out of sync with auth server, often triggered by VPN, private DNS, or device clock drift.',
    rootCauseHi: 'लोकल OAuth सेशन टोकन सर्वर से असंतुलित हो गया है, जो अक्सर VPN, प्राइवेट DNS या डिवाइस की घड़ी गलत होने से होता है।',
    steps: [
      'Ensure your device clock is set to "Automatic date & time" in your phone Settings (SSL certificates reject mismatched clocks).',
      'Temporarily disable any active VPN, proxy, or private AdGuard DNS on your device.',
      'On the Drixvid Sign In screen, tap "Sign In with Email Link" to request a fresh cryptographic magic token.',
      'Important Security Rule: Never share your OTP, password, or verification code with anyone, including support staff.'
    ],
    stepsHi: [
      'सुनिश्चित करें कि आपके फोन सेटिंग्स में "Automatic date & time" ऑन है (घड़ी गलत होने पर SSL टोकन रिजेक्ट हो जाता है)।',
      'यदि कोई VPN या प्राइवेट DNS चालू है, तो उसे कुछ समय के लिए बंद करें।',
      'लॉगिन स्क्रीन पर "Sign In with Email Link" पर टैप करके नया वेरिफिकेशन लिंक प्राप्त करें।',
      'सुरक्षा नियम: कभी भी अपना OTP या पासवर्ड किसी के साथ शेयर न करें।'
    ],
    verificationQuestion: 'Were you able to sign in successfully after clock verification and disabling VPN?',
    verificationQuestionHi: 'क्या घड़ी जांचने और VPN बंद करने के बाद आप सफलतापूर्वक लॉगिन कर पाए?',
    safeActionsOnly: true,
    requiresEscalationIfFails: true,
  },
  {
    id: 'kb-crash-surface-lost',
    category: 'crashes',
    title: 'Crash 0x887A0005: Rendering Surface Lost / Context Dropped',
    titleHi: 'क्रैश 0x887A0005: रेंडरिंग सरफेस लॉस्ट / ऐप फ्रीज',
    errorCode: '0x887A0005',
    keywords: ['0x887a0005', 'surface lost', 'crash', 'freeze', 'gpu', 'webgl', 'black screen', 'engine', 'canvas', 'band', 'bandh'],
    symptoms: [
      'App displays SYSTEM_ERR_SURFACE_LOST context error',
      'Screen freezes during video transition or high frame-rate rendering',
      'App unexpectedly closes back to launcher home'
    ],
    rootCause: 'Hardware GPU WebGL context was reclaimed by Android OS due to low available RAM memory headroom.',
    rootCauseHi: 'कम RAM उपलब्ध होने के कारण फोन ऑपरेटिंग सिस्टम ने WebGL हार्डवेयर सरफेस को बंद कर दिया।',
    steps: [
      'Swipe Drixvid away from your recent applications list to perform a full process release.',
      'Check phone internal storage: ensure you have at least 500 MB of free storage space.',
      'Restart your device to purge clogged background GPU frame buffers.',
      'In Drixvid Settings > Display, toggle "Safe Video Rendering" to reduce GPU memory stress.'
    ],
    stepsHi: [
      'Drixvid ऐप को रीसेंट ऐप्स लिस्ट से स्वाइप करके पूरी तरह बंद करें।',
      'फोन स्टोरेज चेक करें: कम से कम 500 MB खाली जगह होना आवश्यक है।',
      'फोन को एक बार रीस्टार्ट करें ताकि बैकग्राउंड मेमोरी रीफ्रेश हो जाए।',
      'ऐप सेटिंग्स > डिस्प्ले में जाकर "Safe Video Rendering" ऑन करें।'
    ],
    verificationQuestion: 'Did restarting the application stop the unexpected crash or freeze?',
    verificationQuestionHi: 'क्या ऐप को रीस्टार्ट करने से क्रैश होना बंद हो गया?',
    safeActionsOnly: true,
    requiresEscalationIfFails: true,
  },
  {
    id: 'kb-billing-webhook',
    category: 'billing',
    title: 'Billing Delay: Payment Succeeded but Premium Locked (Pending Webhook Sync)',
    titleHi: 'बिलिंग विलंब: बैंक से पैसे कटे लेकिन प्रीमियम चालू नहीं हुआ',
    errorCode: 'PAYMENT_PENDING_WEBHOOK_SYNC',
    keywords: ['billing', 'payment', 'charge', 'money', 'subscription', 'premium', 'pass', 'webhook', 'sync', 'txn', 'paisa'],
    symptoms: [
      'Status displays: Transaction In Progress / TXN_PENDING_WEBHOOK_ACK',
      'Bank debited subscription fee, but Drixvid shows Free tier',
      'Locked premium badge on video catalog'
    ],
    rootCause: 'Bank-to-gateway webhook settlement latency. Payment is captured by payment processor, awaiting token acknowledgment.',
    rootCauseHi: 'बैंक और पेमेंट गेटवे के बीच वेबहुक सिंक में विलंब। पैसे बैंक से कट चुके हैं और टोकन पुष्टिकरण की प्रतीक्षा है।',
    steps: [
      'Go to Drixvid Settings > Subscription > tap "Restore Purchases" to immediately query your billing receipt.',
      'Allow 5 to 10 minutes for automated bank payment reconciliation.',
      'Verify your bank SMS / UPI statement has a Reference ID (TXN / RRN).',
      'Security Note: Never paste full debit/credit card numbers or CVVs into the support chat. If the status remains unverified after 15 minutes, use "Connect to Support Agent" to dispatch a verified ticket with your transaction ID.'
    ],
    stepsHi: [
      'Drixvid सेटिंग्स > सब्सक्रिप्शन में जाकर "Restore Purchases" पर टैप करें।',
      'बैंक और सर्वर के बीच तालमेल के लिए 5 से 10 मिनट प्रतीक्षा करें।',
      'अपने बैंक मैसेज या UPI रसीद में UTR / RRN नंबर सुरक्षित रखें।',
      'सुरक्षा नियम: कभी भी कार्ड नंबर या CVV चैट में न भेजें। यदि 15 मिनट में प्रीमियम न मिले तो "Connect to Support Agent" द्वारा टिकट बनाएं।'
    ],
    verificationQuestion: 'Did tapping "Restore Purchases" unlock your premium entitlement?',
    verificationQuestionHi: 'क्या "Restore Purchases" दबाने से आपका प्रीमियम प्लान एक्टिव हो गया?',
    safeActionsOnly: true,
    requiresEscalationIfFails: true,
  },
  {
    id: 'kb-downloads-scoped-storage',
    category: 'library',
    title: 'Download Failure: Scoped Storage Permission or Full Disk',
    titleHi: 'डाउनलोड विफलता: स्टोरेज परमिशन या मेमोरी फुल',
    errorCode: 'ERR_STORAGE_WRITE_DENIED',
    keywords: ['download', 'downloads', 'save', 'offline', 'storage', 'permission', 'vault', 'fail', 'stuck 99', 'library'],
    symptoms: [
      'Download pauses or fails at 0% or 99%',
      'Error message: Write permission denied to media vault',
      'Offline video does not appear in Downloads tab'
    ],
    rootCause: 'Android 11+ scoped storage media permission was revoked, or device has insufficient write space.',
    rootCauseHi: 'एंड्रॉइड स्टोरेज मीडिया परमिशन बंद है या फोन की मेमोरी डाउनलोड साइज से कम बची है।',
    steps: [
      'Open your phone Settings > Apps > Drixvid > Permissions > ensure "Storage" or "Photos and Videos" is set to "Allow".',
      'Verify you have at least 1 GB of free internal storage on your device.',
      'In Drixvid Settings > Downloads, tap "Repair Download Vault" to rebuild the local offline database index.',
      'Tap "Resume Download" in your Library.'
    ],
    stepsHi: [
      'फोन सेटिंग्स > ऐप्स > Drixvid > Permissions में जाकर "Storage" या "Photos and Videos" को Allow करें।',
      'सुनिश्चित करें कि फोन में कम से कम 1 GB फ्री स्पेस मौजूद है।',
      'Drixvid सेटिंग्स > Downloads में जाकर "Repair Download Vault" पर टैप करें।',
      'लाइब्रेरी में डाउनलोड को दोबारा शुरू (Resume) करें।'
    ],
    verificationQuestion: 'Did verifying storage permissions allow the download to complete?',
    verificationQuestionHi: 'क्या स्टोरेज परमिशन देने से वीडियो डाउनलोड पूरा हो गया?',
    safeActionsOnly: true,
    requiresEscalationIfFails: true,
  },
  {
    id: 'kb-audio-sync',
    category: 'playback',
    title: 'Audio / Video Desync (Lip-Sync Drift > 200ms)',
    titleHi: 'ऑडियो और वीडियो आगे-पीछे होना (AV Desync)',
    keywords: ['audio', 'sound', 'sync', 'delay', 'lag', 'bluetooth', 'desync', 'awaz'],
    symptoms: [
      'Audio plays 1-2 seconds ahead or behind actor lips',
      'Occurs predominantly when connected to Bluetooth earphones or soundbars',
      'Video micro-stutters every few seconds'
    ],
    rootCause: 'Bluetooth SBC/AAC audio latency buffer mismatch with hardware video clock.',
    rootCauseHi: 'ब्लूटूथ ईयरफोन के लेटेंसी बफर और वीडियो क्लॉक में तालमेल न होना।',
    steps: [
      'In the Drixvid video player, pause the video for 2 seconds and tap Play to resynchronize the clock.',
      'Disconnect and reconnect your Bluetooth headset, or switch phone Bluetooth codec to Standard AAC.',
      'In Drixvid Settings > Playback, enable "ExoStream Low-Latency Audio Mode".'
    ],
    stepsHi: [
      'वीडियो को 2 सेकंड रोकें (Pause) और फिर चलाएं (Play) ताकि ऑडियो और वीडियो सिंक हो सके।',
      'ब्लूटूथ हेडफोन को डिस्कनेक्ट करके दोबारा कनेक्ट करें।',
      'ऐप सेटिंग्स > प्लेबैक में जाकर "ExoStream Low-Latency Audio Mode" चालू करें।'
    ],
    verificationQuestion: 'Is the audio and video now playing in perfect synchronization?',
    verificationQuestionHi: 'क्या अब ऑडियो और वीडियो सही तालमेल में चल रहे हैं?',
    safeActionsOnly: true,
    requiresEscalationIfFails: false,
  },
  {
    id: 'kb-subtitles-display',
    category: 'playback',
    title: 'Subtitles Missing, Desynced, or Overlapping',
    titleHi: 'सबटाइटल नहीं दिखना या गलत समय पर आना',
    keywords: ['subtitle', 'subtitles', 'caption', 'captions', 'cc', 'language', 'vtt'],
    symptoms: [
      'Selected subtitle language does not render on screen',
      'Subtitles show 3-4 seconds late',
      'Special characters show as question marks or boxes'
    ],
    rootCause: 'WebVTT track parser timestamp mismatch or UTF-8 font glyph decoding failure.',
    rootCauseHi: 'सबटाइटल टाइमस्टैम्प सिंक या फॉन्ट डिकोडिंग में त्रुटि।',
    steps: [
      'Tap the Subtitle (CC) button on player controls > toggle Subtitles Off, then select your desired language again.',
      'In Drixvid Settings > Subtitles, reset subtitle size to "Medium" and background to "Semi-transparent black".',
      'Ensure device software font size is set to default (not oversized accessibility font).'
    ],
    stepsHi: [
      'प्लेयर में CC (सबटाइटल) बटन दबाएं > सबटाइटल बंद करें और फिर दोबारा अपनी भाषा चुनें।',
      'सेटिंग्स > सबटाइटल में जाकर फॉन्ट साइज Medium पर रीसेट करें।',
      'फोन सेटिंग्स में सिस्टम फॉन्ट साइज को सामान्य (Default) पर रखें।'
    ],
    verificationQuestion: 'Are the subtitles now displaying correctly on your video?',
    verificationQuestionHi: 'क्या सबटाइटल अब सही समय पर स्पष्ट दिख रहे हैं?',
    safeActionsOnly: true,
    requiresEscalationIfFails: false,
  }
];

/**
 * Smart RAG matcher: Finds relevant articles given user query text, category, or error code
 */
export function matchKnowledgeArticles(query: string, category?: string): KnowledgeArticle[] {
  const normalized = query.toLowerCase();
  const tokens = normalized.split(/[\s,._\-:;?!/()]+/).filter((t) => t.length > 2);

  const scored = DRIXVID_KNOWLEDGE_BASE.map((article) => {
    let score = 0;

    // Check specific error code match (high weight)
    if (article.errorCode && normalized.includes(article.errorCode.toLowerCase())) {
      score += 15;
    }

    // Category match
    if (category && article.category === category) {
      score += 3;
    }

    // Keyword matches
    for (const kw of article.keywords) {
      if (normalized.includes(kw.toLowerCase())) {
        score += 4;
      }
    }

    // Symptom and token matches
    for (const token of tokens) {
      if (article.title.toLowerCase().includes(token)) score += 2;
      for (const s of article.symptoms) {
        if (s.toLowerCase().includes(token)) score += 1;
      }
    }

    return { article, score };
  });

  return scored
    .filter((item) => item.score >= 3)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.article)
    .slice(0, 3);
}

/**
 * Format matched knowledge articles into concise context for prompt injection
 */
export function formatKnowledgeForPrompt(articles: KnowledgeArticle[]): string {
  if (articles.length === 0) return 'No pre-verified KB articles directly matched this query.';
  return articles
    .map(
      (a, i) => `[Verified Drixvid Doc #${i + 1}] Title: ${a.title}
Known Root Cause: ${a.rootCause}
Approved Resolution Steps:
${a.steps.map((s, idx) => `  ${idx + 1}. ${s}`).join('\n')}
Verification Check: ${a.verificationQuestion}`
    )
    .join('\n\n');
}
