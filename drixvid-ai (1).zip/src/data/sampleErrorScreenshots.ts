// Helper providing preset sample Drixvid app screenshots for easy testing
export interface PresetScreenshot {
  id: string;
  title: string;
  category: 'playback' | 'account' | 'crashes' | 'billing';
  description: string;
  dataUrl: string;
}

// Generate high-resolution SVG data URLs representing real Drixvid app error screenshots
function createSvgDataUrl(svgContent: string): string {
  const cleanSvg = svgContent.trim();
  const base64 = btoa(unescape(encodeURIComponent(cleanSvg)));
  return `data:image/svg+xml;base64,${base64}`;
}

export const PRESET_ERROR_SCREENSHOTS: PresetScreenshot[] = [
  {
    id: 'preset-playback',
    title: 'Video Player Buffering & Error 4028',
    category: 'playback',
    description: 'Black player viewport with buffer spinner and ERR_STREAM_TIMEOUT 4028',
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" fill="none">
        <rect width="600" height="400" rx="16" fill="#080a10"/>
        <!-- App Top Bar -->
        <rect y="0" width="600" height="40" fill="#0f121d"/>
        <text x="20" y="25" fill="#a0aab8" font-family="sans-serif" font-size="12" font-weight="bold">Drixvid Player v2.4.1</text>
        <circle cx="560" cy="20" r="4" fill="#ef4444"/>
        <text x="500" y="24" fill="#ef4444" font-family="sans-serif" font-size="11">OFFLINE</text>
        <!-- Video Viewport -->
        <rect x="20" y="55" width="560" height="250" rx="12" fill="#020305" stroke="#1f2438"/>
        <!-- Spinner -->
        <circle cx="300" cy="160" r="26" stroke="#06b6d4" stroke-width="4" stroke-dasharray="100 40" stroke-linecap="round"/>
        <text x="300" y="215" fill="#f87171" font-family="monospace" font-size="13" font-weight="bold" text-anchor="middle">
          ERROR 4028: ERR_STREAM_BUFFER_TIMEOUT
        </text>
        <text x="300" y="235" fill="#94a3b8" font-family="sans-serif" font-size="11" text-anchor="middle">
          Media segment fetch dropped at timestamp 04:12 / 12:14
        </text>
        <!-- Scrub bar -->
        <rect x="35" y="280" width="530" height="4" rx="2" fill="#334155"/>
        <rect x="35" y="280" width="160" height="4" rx="2" fill="#ef4444"/>
        <circle cx="195" cy="282" r="5" fill="#ffffff"/>
        <!-- Controls footer -->
        <rect x="20" y="320" width="560" height="60" rx="12" fill="#0f131f"/>
        <text x="40" y="355" fill="#ffffff" font-family="sans-serif" font-size="14" font-weight="bold">
          Tears of Steel: The Cybernetic Reckoning
        </text>
        <text x="520" y="355" fill="#06b6d4" font-family="sans-serif" font-size="12">1080p AI</text>
      </svg>
    `),
  },
  {
    id: 'preset-login',
    title: 'Login Auth SSL Token Expired',
    category: 'account',
    description: 'Auth dialog showing TOKEN_HANDSHAKE_EXPIRED (401)',
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" fill="none">
        <rect width="600" height="400" rx="16" fill="#090b12"/>
        <!-- Top bar -->
        <rect width="600" height="45" fill="#111422"/>
        <text x="24" y="28" fill="#ffffff" font-family="sans-serif" font-size="14" font-weight="bold">Drixvid Sign In</text>
        <!-- Modal Card -->
        <rect x="70" y="80" width="460" height="260" rx="16" fill="#151928" stroke="#f43f5e" stroke-width="1.5"/>
        <circle cx="300" cy="130" r="24" fill="#f43f5e" fill-opacity="0.2"/>
        <text x="300" y="137" fill="#f43f5e" font-family="sans-serif" font-size="22" font-weight="bold" text-anchor="middle">!</text>
        <text x="300" y="180" fill="#ffffff" font-family="sans-serif" font-size="16" font-weight="bold" text-anchor="middle">
          Authentication Session Failed
        </text>
        <text x="300" y="205" fill="#cbd5e1" font-family="monospace" font-size="12" text-anchor="middle">
          [AUTH_ERR_401]: OAuth Token Handshake Dropped
        </text>
        <text x="300" y="230" fill="#94a3b8" font-family="sans-serif" font-size="11" text-anchor="middle">
          Please check device clock sync and active VPN configuration.
        </text>
        <!-- Button -->
        <rect x="200" y="260" width="200" height="36" rx="8" fill="#f43f5e"/>
        <text x="300" y="283" fill="#ffffff" font-family="sans-serif" font-size="12" font-weight="bold" text-anchor="middle">Retry Sign In</text>
      </svg>
    `),
  },
  {
    id: 'preset-crash',
    title: 'WebGL Surface Crash / Freeze',
    category: 'crashes',
    description: 'Black screen with SYSTEM_ERR_SURFACE_LOST context',
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" fill="none">
        <rect width="600" height="400" rx="16" fill="#050608"/>
        <rect x="50" y="100" width="500" height="200" rx="14" fill="#131622" stroke="#eab308" stroke-width="1.5"/>
        <text x="250" y="150" fill="#eab308" font-family="monospace" font-size="14" font-weight="bold">
          [CRASH REPORT: DRIXVID_V2.4]
        </text>
        <text x="90" y="185" fill="#f8fafc" font-family="sans-serif" font-size="13">
          App Rendering Surface Terminated Unexpectedly
        </text>
        <text x="90" y="215" fill="#94a3b8" font-family="monospace" font-size="11">
          Cause: WebGL context lost due to memory headroom limit (Code 0x887A0005)
        </text>
        <text x="90" y="240" fill="#94a3b8" font-family="monospace" font-size="11">
          Stack: at renderFrame (engine.js:412) -> CanvasProvider.reclaim()
        </text>
      </svg>
    `),
  },
  {
    id: 'preset-billing',
    title: 'Payment Entitlement Webhook Delay',
    category: 'billing',
    description: 'Checkout screen showing PAYMENT_PENDING_WEBHOOK_SYNC',
    dataUrl: createSvgDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" width="600" height="400" viewBox="0 0 600 400" fill="none">
        <rect width="600" height="400" rx="16" fill="#090b12"/>
        <rect x="60" y="60" width="480" height="280" rx="16" fill="#121626" stroke="#38bdf8" stroke-width="1"/>
        <text x="300" y="110" fill="#ffffff" font-family="sans-serif" font-size="16" font-weight="bold" text-anchor="middle">
          Drixvid Premium Pass
        </text>
        <circle cx="300" cy="165" r="24" fill="#38bdf8" fill-opacity="0.15"/>
        <circle cx="300" cy="165" r="14" stroke="#38bdf8" stroke-width="3" stroke-dasharray="60 30"/>
        <text x="300" y="225" fill="#facc15" font-family="sans-serif" font-size="13" font-weight="bold" text-anchor="middle">
          Status: Transaction In Progress
        </text>
        <text x="300" y="250" fill="#94a3b8" font-family="monospace" font-size="11" text-anchor="middle">
          Ref: TXN_8849204_PENDING_WEBHOOK_ACK
        </text>
        <text x="300" y="275" fill="#cbd5e1" font-family="sans-serif" font-size="11" text-anchor="middle">
          Bank confirmed charge, waiting for entitlement token handshake.
        </text>
      </svg>
    `),
  },
];
