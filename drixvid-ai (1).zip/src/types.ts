export type TroubleshootingCategory =
  | 'crashes'
  | 'account'
  | 'playback'
  | 'library'
  | 'ai-chat'
  | 'billing'
  | 'settings'
  | 'general';

export type AssistantLanguage = 'en' | 'hi';

export interface DiagnosticInfo {
  appVersion: string;
  buildNumber: string;
  platform: string;
  networkStatus: 'online' | 'offline' | 'poor';
  networkType: string;
  cacheSize: string;
  storageUsage: string;
  servicesStatus: {
    videoCDN: 'operational' | 'degraded' | 'down' | 'unknown';
    authService: 'operational' | 'degraded' | 'down' | 'unknown';
    aiGateway: 'operational' | 'degraded' | 'down' | 'unknown' | 'configured_not_verified' | 'not_configured';
    paymentAPI: 'operational' | 'degraded' | 'down' | 'unknown';
  };
  lastChecked: string;
}

export interface SupportTicket {
  id: string;
  createdAt: string;
  updatedAt: string;
  category: TroubleshootingCategory;
  userDescription: string;
  attemptedSolutions: string[];
  diagnosticSummary: string;
  conversationSummary: string;
  status: 'open' | 'investigating' | 'escalated_to_agent' | 'resolved';
  priority: 'low' | 'normal' | 'high' | 'urgent';
  expectedResponseTime: string;
  agentQueueStatus: string;
  assignedTeam: string;
  contactEmail: string;
}

export interface ChatImageAttachment {
  dataUrl: string;
  mimeType: string;
  fileName?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  image?: ChatImageAttachment;
  hasVerificationButtons?: boolean;
  verificationStatus?: 'unanswered' | 'solved' | 'unresolved';
  ticketId?: string;
  isDemo?: boolean;
  language?: AssistantLanguage;
  category?: TroubleshootingCategory;
  suggestedSteps?: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  messages: ChatMessage[];
  category: TroubleshootingCategory;
  isResolved?: boolean;
  ticketId?: string;
}
