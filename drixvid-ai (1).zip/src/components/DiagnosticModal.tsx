import React, { useState, useEffect } from 'react';
import {
  Activity,
  X,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  ShieldCheck,
  Server,
  Wifi,
  Smartphone,
  HardDrive,
} from 'lucide-react';
import { DiagnosticInfo } from '../types';

interface DiagnosticModalProps {
  isOpen: boolean;
  onClose: () => void;
  diagnosticConsent: boolean;
  onToggleConsent: (allowed: boolean) => void;
  language: 'en' | 'hi';
}

export const DiagnosticModal: React.FC<DiagnosticModalProps> = ({
  isOpen,
  onClose,
  diagnosticConsent,
  onToggleConsent,
  language,
}) => {
  const [diagnostics, setDiagnostics] = useState<DiagnosticInfo | null>(null);
  const [isRunningTest, setIsRunningTest] = useState(false);
  const [pingLatency, setPingLatency] = useState<number | null>(null);

  const fetchDiagnostics = async () => {
    setIsRunningTest(true);
    const start = performance.now();
    try {
      const res = await fetch('/api/diagnostics/status');
      const data = await res.json();
      const end = performance.now();
      setPingLatency(Math.round(end - start));

      // Calculate browser storage if available
      let cacheEstimate = 'Unavailable';
      let storageEstimate = 'Unavailable';
      if (navigator.storage && navigator.storage.estimate) {
        const est = await navigator.storage.estimate();
        if (est.usage) {
          cacheEstimate = `${Math.round(est.usage / (1024 * 1024))} MB`;
        }
      }

      setDiagnostics({
        appVersion: data.appVersion || 'unknown',
        buildNumber: data.buildNumber || 'unknown',
        platform: navigator.userAgent.includes('Android') ? 'Android Webview' : 'Web / Mobile Client',
        networkStatus: navigator.onLine ? 'online' : 'offline',
        networkType: (navigator as any).connection?.effectiveType || 'Unknown',
        cacheSize: cacheEstimate,
        storageUsage: storageEstimate,
        servicesStatus: data.servicesStatus || {
          videoCDN: 'unknown',
          authService: 'unknown',
          aiGateway: 'unknown',
          paymentAPI: 'unknown',
        },
        lastChecked: new Date().toLocaleTimeString(),
      });
    } catch (err) {
      console.error('Failed to run diagnostics:', err);
    } finally {
      setIsRunningTest(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchDiagnostics();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg rounded-3xl glass-dropdown border border-cyan-500/30 p-5 shadow-2xl flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-white">
                {language === 'hi' ? 'Drixvid ऐप डायग्नोस्टिक टूल्स' : 'Drixvid Diagnostic Center'}
              </h3>
              <span className="text-[10px] text-neutral-400">
                {language === 'hi' ? 'केवल उपलब्ध diagnostics; सभी सेवाएँ remote-check नहीं हैं' : 'Available diagnostics only; services are not all remotely checked'}
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real-time Subsystems Status */}
        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-cyan-400" />
              <span>Drixvid Cloud Services Status</span>
            </span>
            <button
              onClick={fetchDiagnostics}
              disabled={isRunningTest}
              className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 font-semibold"
            >
              <RefreshCw className={`w-3 h-3 ${isRunningTest ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
              <span className="text-neutral-300">Video CDN:</span>
              <span className="flex items-center gap-1 font-bold text-neutral-300 text-[11px]">
                <CheckCircle2 className="w-3 h-3" /> {diagnostics?.servicesStatus.videoCDN || 'Unknown'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
              <span className="text-neutral-300">Auth Service:</span>
              <span className="flex items-center gap-1 font-bold text-neutral-300 text-[11px]">
                <CheckCircle2 className="w-3 h-3" /> {diagnostics?.servicesStatus.authService || 'Unknown'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
              <span className="text-neutral-300">AI Gateway:</span>
              <span className="flex items-center gap-1 font-bold text-neutral-300 text-[11px]">
                <CheckCircle2 className="w-3 h-3" /> {diagnostics?.servicesStatus.aiGateway || 'Unknown'}
              </span>
            </div>
            <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
              <span className="text-neutral-300">Payment API:</span>
              <span className="flex items-center gap-1 font-bold text-neutral-300 text-[11px]">
                <CheckCircle2 className="w-3 h-3" /> {diagnostics?.servicesStatus.paymentAPI || 'Unknown'}
              </span>
            </div>
          </div>
        </div>

        {/* Client Device Diagnostics Snapshot */}
        <div className="flex flex-col gap-2">
          <span className="text-xs font-bold text-neutral-300 uppercase tracking-wider flex items-center gap-1.5">
            <Smartphone className="w-3.5 h-3.5 text-purple-400" />
            <span>Client Environment Snapshot</span>
          </span>

          <div className="p-3 rounded-2xl bg-black/40 border border-white/5 flex flex-col gap-2 text-xs font-mono text-neutral-300">
            <div className="flex items-center justify-between">
              <span className="text-neutral-400">App Version:</span>
              <span className="text-white font-bold">{diagnostics?.appVersion || 'Unknown'} (build {diagnostics?.buildNumber || 'Unknown'})</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-400">Network State:</span>
              <span className="text-green-400 flex items-center gap-1">
                <Wifi className="w-3 h-3" /> {diagnostics?.networkStatus === 'online' ? 'Connected' : diagnostics?.networkStatus === 'offline' ? 'Offline' : 'Unknown'} ({diagnostics?.networkType || 'Unknown'})
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-400">API Latency:</span>
              <span className="text-cyan-400 font-semibold">{pingLatency !== null ? `${pingLatency} ms` : 'Measuring...'}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-neutral-400">Cache Footprint:</span>
              <span>{diagnostics?.cacheSize || 'Unavailable'}</span>
            </div>
          </div>
        </div>

        {/* Privacy & Consent Setting */}
        <div className="p-3.5 rounded-2xl bg-purple-950/30 border border-purple-500/20 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-white">Diagnostic Data Permission</span>
            </div>
            <input
              type="checkbox"
              checked={diagnosticConsent}
              onChange={(e) => onToggleConsent(e.target.checked)}
              className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400 accent-cyan-400 cursor-pointer"
            />
          </div>
          <p className="text-[11px] text-neutral-300 leading-relaxed">
            {language === 'hi'
              ? 'समस्या निवारण व सपोर्ट टिकट में केवल तकनीकी डायग्नोस्टिक जानकारी (ऐप वर्ज़न, नेटवर्क स्थिति) शामिल की जाएगी। हम कभी भी पासवर्ड या वित्तीय डेटा एकत्र नहीं करते।'
              : 'Include technical device diagnostics in support tickets to help engineers resolve issues faster. Passwords and credentials are never collected.'}
          </p>
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
