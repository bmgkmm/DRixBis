import React, { useState, useRef, useEffect } from 'react';
import {
  Wrench,
  MoreVertical,
  Plus,
  Globe,
  Check,
} from 'lucide-react';
import { AssistantLanguage } from '../types';

interface HeaderProps {
  language: AssistantLanguage;
  onLanguageChange: (lang: AssistantLanguage) => void;
  isMobileFrame: boolean;
  onToggleMobileFrame: () => void;
  onNewTroubleshoot: () => void;
  onOpenDiagnostics: () => void;
  onOpenTickets: () => void;
  ticketsCount: number;
  aiConfigStatus: 'checking' | 'configured' | 'not_configured';
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  isMobileFrame,
  onToggleMobileFrame,
  onNewTroubleshoot,
  onOpenDiagnostics,
  onOpenTickets,
  ticketsCount,
  aiConfigStatus,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#090a0f]/95 backdrop-blur-xl border-b border-white/10 select-none flex-shrink-0">
      <div className="max-w-4xl mx-auto px-3.5 py-2.5 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2.5 cursor-pointer" onClick={onNewTroubleshoot} title="Drixvid AI Solver">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-400 via-indigo-600 to-purple-600 p-[1.5px] shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-[#0c0e14] rounded-[10px] flex items-center justify-center relative overflow-hidden">
              <Wrench className="w-4 h-4 text-cyan-400" />
            </div>
          </div>

          <div className="flex flex-col">
            <span className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-white via-neutral-100 to-neutral-400 bg-clip-text text-transparent">
              DRIXVID AI
            </span>
          </div>
        </div>

        {/* Clean Single Menu Dropdown */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 active:scale-95 transition-all"
            aria-label="Options menu"
            title="Menu & Settings"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 rounded-2xl bg-[#12141f] border border-white/10 p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150 backdrop-blur-xl">
              {/* New Case */}
              <button
                onClick={() => {
                  onNewTroubleshoot();
                  setIsMenuOpen(false);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-neutral-200 hover:bg-white/10 transition-colors font-medium text-left"
              >
                <Plus className="w-4 h-4 text-cyan-400" />
                <span>{language === 'hi' ? 'नया केस शुरू करें' : 'Start New Case'}</span>
              </button>

              {/* Language Switch */}
              <div className="border-t border-white/10 my-1 pt-1">
                <div className="px-3 py-1 text-[10px] font-bold text-neutral-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Globe className="w-3 h-3 text-cyan-400" />
                  <span>Language / भाषा</span>
                </div>
                <div className="flex gap-1 p-1">
                  <button
                    onClick={() => {
                      onLanguageChange('en');
                      setIsMenuOpen(false);
                    }}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      language === 'en'
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'text-neutral-400 hover:bg-white/5'
                    }`}
                  >
                    <span>English</span>
                    {language === 'en' && <Check className="w-3 h-3 text-cyan-400" />}
                  </button>
                  <button
                    onClick={() => {
                      onLanguageChange('hi');
                      setIsMenuOpen(false);
                    }}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      language === 'hi'
                        ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                        : 'text-neutral-400 hover:bg-white/5'
                    }`}
                  >
                    <span>हिन्दी</span>
                    {language === 'hi' && <Check className="w-3 h-3 text-purple-400" />}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
