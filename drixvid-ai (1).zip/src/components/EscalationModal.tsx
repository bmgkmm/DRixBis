import React, { useState } from 'react';
import {
  UserCheck,
  X,
  Send,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileText,
  Clock,
  Ticket,
  Mail,
  Copy,
  Check,
  ExternalLink,
  Flame,
} from 'lucide-react';
import { SupportTicket, TroubleshootingCategory } from '../types';
import { saveLocalTicket } from '../utils/storage';
import { generateGmailDispatch, EmailDispatchPayload } from '../utils/gmailDispatcher';

interface EscalationModalProps {
  isOpen: boolean;
  onClose: () => void;
  category: TroubleshootingCategory;
  userDescription: string;
  attemptedSolutions: string[];
  conversationSummary: string;
  diagnosticConsent: boolean;
  onTicketCreated: (ticket: SupportTicket) => void;
  language: 'en' | 'hi';
}

export const EscalationModal: React.FC<EscalationModalProps> = ({
  isOpen,
  onClose,
  category,
  userDescription,
  attemptedSolutions,
  conversationSummary,
  diagnosticConsent,
  onTicketCreated,
  language,
}) => {
  const [email, setEmail] = useState('');
  const [userNote, setUserNote] = useState(userDescription);
  const [includeDiagnostics, setIncludeDiagnostics] = useState(diagnosticConsent);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdTicket, setCreatedTicket] = useState<SupportTicket | null>(null);
  const [dispatchData, setDispatchData] = useState<EmailDispatchPayload | null>(null);
  const [isFirebaseSynced, setIsFirebaseSynced] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const payload = {
        category,
        userDescription: userNote || userDescription || 'Unresolved technical issue in Drixvid app.',
        attemptedSolutions,
        diagnosticSummary: includeDiagnostics
          ? `Browser: ${navigator.userAgent.slice(0, 240)}; Network online: ${navigator.onLine ? 'yes' : 'no'}. No server health claims included.`
          : 'User opted out of diagnostic snapshot attachment.',
        conversationSummary: conversationSummary || userDescription,
        userEmail: email,
      };

      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error('Failed to generate ticket');

      const data = await res.json();
      const ticket: SupportTicket = data.ticket;
      saveLocalTicket(ticket);

      // Generate Gmail dispatch info
      const dispatch = generateGmailDispatch(ticket);
      setDispatchData(dispatch);

      // Firestore ticket sync is intentionally disabled until per-user auth/rules are configured.
      // The ticket is saved locally and the user can explicitly send the prepared email.
      setIsFirebaseSynced(false);

      setCreatedTicket(ticket);
      onTicketCreated(ticket);
    } catch (err) {
      console.error(err);
      alert('Unable to submit ticket. Please check connection and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyDispatch = () => {
    if (!dispatchData) return;
    navigator.clipboard.writeText(dispatchData.bodyText);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-lg rounded-3xl glass-dropdown border border-purple-500/30 p-5 shadow-2xl flex flex-col gap-4 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-cyan-400" />
            <h3 className="font-extrabold text-sm sm:text-base text-white">
              {language === 'hi' ? 'सपोर्ट एजेंट से कनेक्ट करें' : 'Connect to Support Agent'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {createdTicket && dispatchData ? (
          /* Confirmation View with Professional Gmail & Firebase Dispatch */
          <div className="flex flex-col gap-4 py-2 animate-in fade-in text-center items-center">
            <div className="w-14 h-14 rounded-2xl bg-green-500/20 text-green-400 border border-green-500/30 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-green-400 block mb-1">
                Ticket Created · Email Not Sent Yet
              </span>
              <h4 className="text-xl font-mono font-extrabold text-white">
                Ticket ID: {createdTicket.id}
              </h4>
              <p className="text-xs text-neutral-400 mt-1 max-w-sm">
                Your issue has been saved as a ticket. Open the email draft below and press Send if you want to contact support.
              </p>
            </div>

            {/* Badges for Firebase & Gmail */}
            <div className="flex items-center gap-2 flex-wrap justify-center">
              <div className="px-2.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-bold flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>{isFirebaseSynced ? 'Synced to Firebase Firestore' : 'Cloud sync disabled'}</span>
              </div>
              <div className="px-2.5 py-1 rounded-full bg-red-500/15 border border-red-500/30 text-red-300 text-[11px] font-bold flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-red-400" />
                <span>drixvidofficial@gmail.com</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="w-full flex flex-col gap-2 pt-2">
              <a
                href={dispatchData.gmailComposeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-500/25 transition-transform active:scale-98"
              >
                <Mail className="w-4 h-4" />
                <span>Send via Gmail to drixvidofficial@gmail.com</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-80" />
              </a>

              <div className="grid grid-cols-2 gap-2">
                <a
                  href={dispatchData.mailtoUrl}
                  className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Default Mail App</span>
                </a>
                <button
                  type="button"
                  onClick={handleCopyDispatch}
                  className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  {isCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-green-400" />
                      <span className="text-green-300">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-purple-400" />
                      <span>Copy Dispatch</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="w-full p-3 rounded-2xl bg-white/5 border border-white/5 text-left text-xs flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Status:</span>
                <span className="font-bold text-amber-400">Escalated to Agent</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Expected Response:</span>
                <span className="font-semibold text-neutral-200">Not configured</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-400">Routing Email:</span>
                <span className="font-mono text-cyan-300">drixvidofficial@gmail.com</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-neutral-300 font-bold text-xs transition-colors"
            >
              Return to Support Chat
            </button>
          </div>
        ) : (
          /* Creation Form */
          <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
            {/* Live queue status disclaimer */}
            <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-start gap-2">
              <Clock className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Support Notice: </span>
                Real-time agent chat is offline. A ticket record will be created. No live agent is connected, and the email will not be sent automatically.
              </div>
            </div>

            {/* Problem Category & Summary */}
            <div>
              <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block mb-1">
                Issue Summary (Preserved from Chat)
              </label>
              <textarea
                rows={2}
                value={userNote}
                onChange={(e) => setUserNote(e.target.value)}
                placeholder="Describe what occurred in the app..."
                className="w-full bg-[#0a0c12] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Attempted Solutions Review */}
            {attemptedSolutions.length > 0 && (
              <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-xs">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-1">
                  Troubleshooting Steps Already Attempted:
                </span>
                <ul className="list-disc list-inside space-y-0.5 text-neutral-300 text-[11px]">
                  {attemptedSolutions.map((step, idx) => (
                    <li key={idx} className="truncate">{step}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Email field */}
            <div>
              <label className="text-xs font-bold text-neutral-300 uppercase tracking-wider block mb-1">
                Your Contact Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#0a0c12] border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Diagnostic Consent Checkbox */}
            <div className="p-3 rounded-2xl bg-purple-950/20 border border-purple-500/20 flex items-start gap-2.5">
              <input
                type="checkbox"
                id="escalation-diag"
                checked={includeDiagnostics}
                onChange={(e) => setIncludeDiagnostics(e.target.checked)}
                className="w-4 h-4 rounded text-cyan-400 accent-cyan-400 mt-0.5 cursor-pointer"
              />
              <label htmlFor="escalation-diag" className="text-xs text-neutral-300 cursor-pointer">
                <span className="font-bold text-white block">Attach Diagnostic System Snapshot</span>
                <span className="text-[11px] text-neutral-400">
                  Only basic browser/network details are included if you consent. App version, server health, and cache state are not verified here.
                </span>
              </label>
            </div>

            {/* Submit */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-neutral-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 to-purple-600 hover:opacity-90 disabled:opacity-50 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
              >
                <Ticket className="w-3.5 h-3.5 fill-black" />
                <span>{isSubmitting ? 'Creating Ticket...' : 'Create Ticket & Prepare Email'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
