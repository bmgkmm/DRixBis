import React, { useState, useEffect } from 'react';
import {
  Ticket,
  X,
  Clock,
  CheckCircle2,
  AlertCircle,
  Headphones,
  UserCheck,
  Mail,
  ChevronRight,
  Shield,
  RefreshCw,
} from 'lucide-react';
import { SupportTicket } from '../types';

interface TicketsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  tickets: SupportTicket[];
  onRefreshTickets: () => void;
  language: 'en' | 'hi';
}

export const TicketsDrawer: React.FC<TicketsDrawerProps> = ({
  isOpen,
  onClose,
  tickets,
  onRefreshTickets,
  language,
}) => {
  const [agentStatus, setAgentStatus] = useState<{
    isLiveAgentAvailable: boolean;
    reason?: string;
    expectedResponseTime?: string;
    fallbackMethod?: string;
    contactEmail?: string;
    businessHours?: string;
  } | null>(null);

  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/agents/status')
        .then((res) => res.json())
        .then((data) => setAgentStatus(data))
        .catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-end animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-[#0c0d16] border-l border-white/10 h-full p-4 flex flex-col justify-between shadow-2xl animate-in slide-in-from-right duration-200">
        <div className="flex flex-col gap-4 overflow-y-auto pr-1">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Ticket className="w-5 h-5 text-cyan-400" />
              <div>
                <h3 className="font-extrabold text-sm sm:text-base text-white">
                  {language === 'hi' ? 'सपोर्ट टिकट्स व एजेंट स्थिति' : 'Support Tickets & Escalations'}
                </h3>
                <span className="text-[10px] text-neutral-400">
                  {tickets.length} {language === 'hi' ? 'टिकट दर्ज' : 'logged cases'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={onRefreshTickets}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/5 transition-colors"
                title="Refresh tickets"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/5 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Actual Live Agent Queue Availability Notice (No simulated fake human connection) */}
          <div className="p-3.5 rounded-2xl bg-[#141624] border border-white/10 flex flex-col gap-2 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Headphones className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-white">Live Support Agent System</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-bold">
                Queue Offline
              </span>
            </div>

            <p className="text-[11px] text-neutral-300 leading-relaxed">
              {language === 'hi'
                ? 'लाइव ह्यूमन चैट अभी कॉन्फ़िगर नहीं है। अनसुलझी समस्या के लिए टिकट और ईमेल ड्राफ्ट बनाया जा सकता है; ईमेल अपने आप नहीं भेजा जाता।'
                : 'Direct live chat queue is currently offline. As per Drixvid support policy, an unresolved issue can be saved as a ticket and an email draft can be opened manually.'}
            </p>

            <div className="flex items-center justify-between text-[10px] text-neutral-400 pt-1 border-t border-white/5">
              <span>Expected response: not configured</span>
              <span className="text-cyan-400 font-medium">drixvidofficial@gmail.com</span>
            </div>
          </div>

          {/* Ticket Detail Modal / View */}
          {selectedTicket ? (
            <div className="p-4 rounded-2xl bg-white/5 border border-cyan-500/30 flex flex-col gap-3 animate-in fade-in">
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setSelectedTicket(null)}
                  className="text-xs text-cyan-400 font-semibold hover:underline"
                >
                  ← Back to all tickets
                </button>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300">
                  {selectedTicket.priority} Priority
                </span>
              </div>

              <div>
                <span className="text-xs font-mono font-bold text-cyan-300">{selectedTicket.id}</span>
                <h4 className="text-sm font-bold text-white mt-1 capitalize">
                  {selectedTicket.category} Issue
                </h4>
                <span className="text-[10px] text-neutral-500">{selectedTicket.createdAt}</span>
              </div>

              <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-xs text-neutral-200">
                <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">
                  User Issue Statement:
                </span>
                <p className="leading-relaxed">{selectedTicket.userDescription}</p>
              </div>

              {selectedTicket.attemptedSolutions.length > 0 && (
                <div className="text-xs">
                  <span className="text-[10px] uppercase font-bold text-neutral-400 block mb-1">
                    Attempted Solutions:
                  </span>
                  <ul className="list-disc list-inside space-y-1 text-neutral-300 text-[11px]">
                    {selectedTicket.attemptedSolutions.map((sol, idx) => (
                      <li key={idx}>{sol}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="p-2.5 rounded-xl bg-purple-950/20 border border-purple-500/20 text-[11px] text-purple-200 flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold">Support routing:</span>
                  <span className="text-[10px] text-amber-300 font-semibold">Cloud sync disabled</span>
                </div>
                <span>{selectedTicket.assignedTeam}</span>
                <span className="text-[10px] text-neutral-400 mt-1">
                  Email draft recipient: drixvidofficial@gmail.com (manual send required)
                </span>
              </div>

              {/* Direct Gmail & Email Action */}
              <div className="flex flex-col gap-2 pt-1">
                <a
                  href={`https://mail.google.com/mail/?view=cm&fs=1&to=drixvidofficial@gmail.com&su=${encodeURIComponent(`[DRIXVID ESCALATION] Ticket #${selectedTicket.id}: ${selectedTicket.category.toUpperCase()}`)}&body=${encodeURIComponent(`Drixvid Escalation #${selectedTicket.id}\nIssue: ${selectedTicket.userDescription}\nSteps Attempted: ${selectedTicket.attemptedSolutions.join(', ')}\nTelemetry: ${selectedTicket.diagnosticSummary}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Send via Gmail to drixvidofficial@gmail.com</span>
                </a>
              </div>
            </div>
          ) : (
            /* Tickets List */
            <div className="flex flex-col gap-2">
              <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                {language === 'hi' ? 'आपके हालिया टिकट्स' : 'Your Support Tickets'}
              </span>

              {tickets.length === 0 ? (
                <div className="p-8 rounded-2xl bg-white/[0.02] border border-white/5 text-center flex flex-col items-center gap-2">
                  <Ticket className="w-8 h-8 text-neutral-600" />
                  <h4 className="text-xs font-bold text-neutral-300">No support tickets filed yet</h4>
                  <p className="text-[11px] text-neutral-500 max-w-xs">
                    If Drixvid AI cannot resolve your problem, you can escalate and generate a ticket here.
                  </p>
                </div>
              ) : (
                tickets.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTicket(t)}
                    className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-cyan-500/30 cursor-pointer transition-all flex items-center justify-between group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-cyan-300">{t.id}</span>
                        <span className="text-[9px] uppercase font-bold px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300">
                          {t.category}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-200 font-medium line-clamp-1 mt-1">
                        {t.userDescription}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-neutral-500 mt-1">
                        <Clock className="w-3 h-3" />
                        <span>{t.createdAt}</span>
                        <span>•</span>
                        <span className="text-amber-400 font-semibold">{t.status}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-neutral-500 group-hover:text-cyan-400 transition-colors flex-shrink-0" />
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] text-neutral-400">
          <span className="flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>Encrypted Diagnostic Data</span>
          </span>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
