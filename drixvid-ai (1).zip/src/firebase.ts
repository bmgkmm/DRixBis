import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { SupportTicket } from './types';

// Initialize Firebase
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Validate connection on boot
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    console.warn('Firestore connectivity could not be verified:', error instanceof Error ? error.message : String(error));
    return false;
  }
}

// Ticket cloud sync is disabled until authenticated per-user ownership and restrictive rules are configured.
export async function syncTicketToFirestore(_ticket: SupportTicket): Promise<boolean> {
  console.warn('Ticket cloud sync is disabled for privacy; ticket is stored locally and email must be sent manually.');
  return false;
}

export async function fetchTicketsFromFirestore(): Promise<SupportTicket[]> {
  return [];
}

