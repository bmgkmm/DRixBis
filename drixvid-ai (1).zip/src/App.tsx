import React, { useState, useRef, useEffect } from 'react';
import {
  Wrench,
  Send,
  Sparkles,
  CheckCircle2,
  XCircle,
  Headphones,
  UserCheck,
  AlertTriangle,
  Activity,
  Ticket,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  RefreshCw,
  ArrowRight,
  Wifi,
  Battery,
  Signal,
  CheckCheck,
  Lock,
  PlayCircle,
  HelpCircle,
  Image as ImageIcon,
  X,
  Maximize2,
  Eye,
} from 'lucide-react';
import {
  ChatMessage,
  SupportTicket,
  TroubleshootingCategory,
  AssistantLanguage,
  ChatImageAttachment,
} from './types';
import {
  getLocalTickets,
  getDiagnosticConsent,
  setDiagnosticConsent,
  getAppLanguage,
  setAppLanguage,
} from './utils/storage';
import { Header } from './components/Header';
import { DiagnosticModal } from './components/DiagnosticModal';
import { TicketsDrawer } from './components/TicketsDrawer';
import { EscalationModal } from './components/EscalationModal';

export default function App() {
  const [language, setLanguage] = useState<AssistantLanguage>(getAppLanguage());
  const [aiConfigStatus, setAiConfigStatus] = useState<'checking' | 'configured' | 'not_configured'>('checking');
  const [isMobileFrame, setIsMobileFrame] = useState(false);
  const [activeCategory, setActiveCategory] = useState<TroubleshootingCategory>('general');

  // Modals state
  const [isDiagnosticOpen, setIsDiagnosticOpen] = useState(false);
  const [isTicketsOpen, setIsTicketsOpen] = useState(false);
  const [isEscalationOpen, setIsEscalationOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // Tickets and Consent
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [diagnosticConsent, setConsentState] = useState(getDiagnosticConsent());

  // Conversation state
  const getInitialWelcome = (lang: AssistantLanguage): ChatMessage => ({
    id: 'welcome-solver',
    role: 'assistant',
    content:
      lang === 'hi'
        ? `नमस्ते! मैं **Drixvid AI — Smart App Problem Solver** हूँ।

मैं Drixvid ऐप की समस्याओं को समझने और उन्हें चरण-दर-चरण हल करने में मदद करता हूँ।
🖼️ **स्क्रीनशॉट सहायता:** नीचे Gallery बटन से स्क्रीनशॉट भेजें। उपलब्ध AI सेवा उसकी जाँच करके संभावित कारण और सुरक्षित समाधान बताएगी।

- ⚡ **ऐप क्रैश, फ्रीज व लोडिंग समस्याएं**
- 🎬 **वीडियो प्लेबैक और बफ़रिंग समस्याएँ**
- 🔐 **लॉगिन, साइनअप व टोकन एक्सपायर**
- 💳 **सब्सक्रिप्शन पेमेंट व सिंक पेंडिंग**`
        : `Hello! I am **Drixvid AI — Smart App Problem Solver**.

I specialize in helping users troubleshoot DrixVid app issues.
🖼️ **Screenshot support:** Send an app screenshot using the **Gallery** button below. When the AI service is configured, it can inspect visible errors and suggest safe troubleshooting steps.

- ⚡ **App crashes, freezes & loading loops**
- 🎬 **Video playback and buffering issues**
- 🔐 **Login, signup & token handshake failures**
- 💳 **Subscription payments & entitlement sync**`,
    timestamp: 'Just now',
    category: 'general',
  });

  const [messages, setMessages] = useState<ChatMessage[]>([getInitialWelcome(language)]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Pending image attachment for sending
  const [attachedImage, setAttachedImage] = useState<ChatImageAttachment | null>(null);

  // Attempted steps accumulator for current case
  const [attemptedSteps, setAttemptedSteps] = useState<string[]>([]);
  const [caseDescription, setCaseDescription] = useState<string>('');

  // Speech & Copy
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  // File input refs
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load tickets on mount & sync with server
  const refreshTickets = async () => {
    try {
      const res = await fetch('/api/tickets');
      if (res.ok) {
        const data = await res.json();
        setTickets([...(data.tickets || []), ...getLocalTickets()].filter((ticket, index, all) => all.findIndex((item) => item.id === ticket.id) === index));
      } else {
        setTickets(getLocalTickets());
      }
    } catch {
      setTickets(getLocalTickets());
    }
  };

  useEffect(() => {
    refreshTickets();
    fetch('/api/ai/status')
      .then((res) => res.ok ? res.json() : Promise.reject(new Error('status unavailable')))
      .then((data) => setAiConfigStatus(data.configured ? 'configured' : 'not_configured'))
      .catch(() => setAiConfigStatus('not_configured'));
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading, attachedImage]);

  const handleLanguageChange = (newLang: AssistantLanguage) => {
    setLanguage(newLang);
    setAppLanguage(newLang);
    if (messages.length === 1 && messages[0].id === 'welcome-solver') {
      setMessages([getInitialWelcome(newLang)]);
    }
  };

  const handleToggleConsent = (allowed: boolean) => {
    setConsentState(allowed);
    setDiagnosticConsent(allowed);
  };

  // Image Upload handler (converts File to dataUrl and base64)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const supportedImageTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!supportedImageTypes.includes(file.type.toLowerCase())) {
      alert('Please select a PNG, JPG, or WEBP screenshot.');
      e.target.value = '';
      return;
    }
    if (file.size > 6 * 1024 * 1024) {
      alert('Please choose an image smaller than 6 MB for reliable AI analysis.');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setAttachedImage({
        dataUrl,
        mimeType: file.type,
        fileName: file.name,
      });
      // Clear file input so same file can be re-selected if removed
      e.target.value = '';
    };
    reader.readAsDataURL(file);
  };


  // Send message to troubleshooting engine
  const handleSendMessage = async (queryText?: string, catOverride?: TroubleshootingCategory) => {
    const textToSend = (queryText ?? input).trim();
    if ((!textToSend && !attachedImage) || isLoading) return;

    const cat = catOverride || activeCategory;
    if (!caseDescription) {
      setCaseDescription(textToSend || attachedImage?.fileName || 'Screenshot issue');
    }

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: textToSend || (language === 'hi' ? 'कृपया इस स्क्रीनशॉट की जांच करें और समाधान बताएं।' : 'Please inspect this attached screenshot and diagnose the problem.'),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      category: cat,
      language,
      image: attachedImage ? { ...attachedImage } : undefined,
    };

    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setInput('');
    const currentAttachment = attachedImage;
    setAttachedImage(null);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          // Keep payloads bounded: send recent text context and only the newest screenshot.
          messages: nextMessages.slice(-12).map((m, index, recent) => ({
            role: m.role,
            content: m.content,
            image: m.image && index === recent.length - 1
              ? { dataUrl: m.image.dataUrl, mimeType: m.image.mimeType }
              : undefined,
          })),
          language,
          category: cat,
          diagnosticConsent,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Support AI request failed (${response.status}).`);
      }

      const data = await response.json();

      if (data.suggestedSteps && Array.isArray(data.suggestedSteps)) {
        setAttemptedSteps((prev) => Array.from(new Set([...prev, ...data.suggestedSteps])));
      }

      const assistantMessage: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        content: data.reply || 'Let us inspect this Drixvid issue step by step.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        hasVerificationButtons: Boolean(data.hasVerificationButtons),
        verificationStatus: 'unanswered',
        isDemo: Boolean(data.isDemo),
        category: cat,
        language,
      };

      setMessages([...nextMessages, assistantMessage]);
    } catch (err) {
      console.error('Diagnostic call error:', err);
      const safeErrorMessage = err instanceof Error ? err.message.slice(0, 220) : 'Network request failed';
      const fallbackMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        content:
          language === 'hi'
            ? `### Support AI अस्थायी रूप से उपलब्ध नहीं है
मैं अभी आपके संदेश/स्क्रीनशॉट का भरोसेमंद विश्लेषण नहीं कर पाया, इसलिए कोई कारण अनुमान से नहीं बताऊँगा।

1. कुछ देर बाद दोबारा कोशिश करें।
2. API key, model या quota की समस्या हो तो server configuration जाँचें।
3. जरूरत हो तो **Connect to Support Agent** चुनें।

विवरण: ${safeErrorMessage}`
            : `### Support AI is temporarily unavailable
I could not reliably analyze your message or screenshot, so I won't guess at the cause.

1. Please try again in a moment.
2. If this is an API configuration, model, or quota error, check the server setup.
3. If needed, choose **Connect to Support Agent**.

Details: ${safeErrorMessage}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        hasVerificationButtons: false,
        verificationStatus: 'unanswered',
        isDemo: true,
      };
      setMessages([...nextMessages, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Verification button handler: "Yes, problem solved"
  const handleProblemSolved = (messageId: string) => {
    // Find assistant message and triggering user query
    const targetIdx = messages.findIndex((m) => m.id === messageId);
    const asstMsg = targetIdx !== -1 ? messages[targetIdx] : null;
    const userQueryMsg = targetIdx > 0 ? messages[targetIdx - 1] : null;

    // User feedback is recorded in this chat only; it is not automatically treated as verified training data.

    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, verificationStatus: 'solved' } : m))
    );

    const resolutionMsg: ChatMessage = {
      id: `sys-${Date.now()}`,
      role: 'assistant',
      content:
        language === 'hi'
          ? `धन्यवाद! आपने बताया कि यह समाधान मददगार रहा। इस feedback को अपने आप verified training data नहीं माना जाता। इससे AI की knowledge base में बदलाव नहीं किया गया है।`
          : `Thanks for confirming the issue is resolved. This feedback is not automatically treated as verified training data, and it has not been added to the AI knowledge base.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      category: activeCategory,
    };

    setMessages((prev) => [...prev, resolutionMsg]);
  };

  // Verification button handler: "No, problem still exists"
  const handleProblemStillExists = (messageId: string) => {
    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, verificationStatus: 'unresolved' } : m))
    );

    const escalationNoticeMsg: ChatMessage = {
      id: `sys-${Date.now()}`,
      role: 'assistant',
      content:
        language === 'hi'
          ? `⚠️ **स्वचालित एस्केलेशन प्रारंभ:** प्राथमिक निवारण से समस्या का समाधान नहीं हुआ।

📩 नीचे दिए गए **"Connect to Support Agent"** बटन पर टैप करें।
यह सपोर्ट टिकट बनाएगा और ईमेल भेजने के लिए ड्राफ्ट तैयार करेगा। ईमेल अपने आप नहीं भेजा जाता; आपको Gmail में Send दबाना होगा।`
          : `⚠️ **Automatic Escalation Protocol Activated:** Automated troubleshooting did not resolve your issue.

📩 Tap the **"Connect to Support Agent"** button below.
This creates a support ticket and prepares an email draft. Email is not sent automatically; you must press Send in Gmail.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      category: activeCategory,
    };

    setMessages((prev) => [...prev, escalationNoticeMsg]);
  };

  // Reset case
  const handleNewTroubleshoot = () => {
    setMessages([getInitialWelcome(language)]);
    setAttemptedSteps([]);
    setCaseDescription('');
    setInput('');
    setAttachedImage(null);
  };

  // Copy
  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Read Aloud
  const toggleSpeech = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#`_]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = language === 'hi' ? 'hi-IN' : 'en-US';
    utterance.rate = 1.0;
    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Voice Input (Speech-to-Text)
  const toggleVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = language === 'hi' ? 'hi-IN' : 'en-US';
      recognition.interimResults = false;
      recognition.continuous = false;

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  // Status clock for mobile frame mode
  const [timeStr, setTimeStr] = useState('9:41');
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const timer = setInterval(updateTime, 30000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="h-screen h-[100dvh] w-full bg-[#07080b] text-neutral-100 flex flex-col items-center justify-center p-0 overflow-hidden selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Hidden file input for gallery */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      {/* Device wrapper */}
      <div
        className={`w-full h-full flex flex-col bg-[#090a0f] relative overflow-hidden ${
          isMobileFrame
            ? 'max-w-md h-[92vh] max-h-[920px] rounded-[42px] border-[8px] border-[#1e2230] shadow-[0_0_60px_rgba(0,0,0,0.8)] ring-1 ring-white/10'
            : 'max-w-4xl md:h-[96vh] md:max-h-[960px] md:rounded-3xl border-0 md:border md:border-white/5 shadow-2xl'
        }`}
      >
        {/* Android Phone Top Status Bar in Mobile View */}
        {isMobileFrame && (
          <div className="bg-[#090a0f] text-neutral-400 px-6 pt-3 pb-1 flex items-center justify-between text-[11px] font-semibold select-none z-50">
            <span>{timeStr}</span>
            <div className="w-3.5 h-3.5 rounded-full bg-black border border-neutral-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-neutral-900" />
            </div>
            <div className="flex items-center gap-1.5 text-neutral-400">
              <Signal className="w-3 h-3 text-neutral-300" />
              <Wifi className="w-3 h-3 text-neutral-300" />
              <Battery className="w-3.5 h-3.5 text-neutral-300" />
            </div>
          </div>
        )}

        {/* Top Header */}
        <Header
          language={language}
          onLanguageChange={handleLanguageChange}
          isMobileFrame={isMobileFrame}
          onToggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
          onNewTroubleshoot={handleNewTroubleshoot}
          onOpenDiagnostics={() => setIsDiagnosticOpen(true)}
          onOpenTickets={() => setIsTicketsOpen(true)}
          ticketsCount={tickets.length}
          aiConfigStatus={aiConfigStatus}
        />

        {/* Chat Feed */}
        <main className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-3 sm:px-5 py-3 flex flex-col gap-3">
          {/* Messages List */}
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isAssistant = msg.role === 'assistant';

            return (
              <div
                key={msg.id}
                className={`flex items-start gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-400 to-purple-600 p-[1.5px] flex-shrink-0 mt-0.5 shadow-md">
                    <div className="w-full h-full bg-[#0a0b10] rounded-[10px] flex items-center justify-center">
                      <Wrench className="w-4 h-4 text-cyan-400" />
                    </div>
                  </div>
                )}

                <div
                  className={`max-w-[90%] sm:max-w-[80%] rounded-2xl px-3.5 py-2.5 sm:px-4 sm:py-3 shadow-lg text-xs sm:text-sm leading-relaxed ${
                    isUser
                      ? 'bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 text-white rounded-br-none'
                      : 'bg-[#12141f] text-neutral-200 border border-white/10 rounded-bl-none'
                  }`}
                >
                  {/* Category Pill Tag */}
                  {!isUser && msg.category && msg.category !== 'general' && (
                    <div className="mb-2 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-950/40 border border-purple-500/30 text-purple-300 text-[10px] font-semibold uppercase tracking-wider">
                      <span>Category: {msg.category}</span>
                    </div>
                  )}

                  {/* Render Attached Image if present in message */}
                  {msg.image && (
                    <div className="mb-2.5 rounded-xl overflow-hidden border border-white/20 bg-black/50 group relative">
                      <img
                        src={msg.image.dataUrl}
                        alt={msg.image.fileName || 'Attached screenshot'}
                        className="max-h-60 w-full object-contain cursor-pointer transition-transform group-hover:scale-[1.02]"
                        onClick={() => setLightboxImage(msg.image?.dataUrl || null)}
                      />
                      <div
                        onClick={() => setLightboxImage(msg.image?.dataUrl || null)}
                        className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-1.5 text-xs text-white cursor-pointer transition-opacity backdrop-blur-[2px]"
                      >
                        <Eye className="w-4 h-4" />
                        <span>Tap to enlarge screenshot</span>
                      </div>
                      <div className="p-1.5 bg-black/75 text-[10px] text-neutral-300 flex items-center justify-between border-t border-white/10">
                        <span className="truncate max-w-[200px]">📸 {msg.image.fileName || 'App Screenshot'}</span>
                        <span className="text-cyan-400 font-semibold">Screenshot attached</span>
                      </div>
                    </div>
                  )}

                  {/* Message Content */}
                  <div className="whitespace-pre-wrap space-y-1.5 font-normal">
                    {renderFormattedContent(msg.content)}
                  </div>

                  {/* Verification Block ("Did this solve your problem?") */}
                  {isAssistant && msg.hasVerificationButtons && (
                    <div className="mt-3.5 pt-3 border-t border-white/10 flex flex-col gap-2.5 bg-black/40 -mx-2 p-3 rounded-xl">
                      <div className="flex items-center gap-1.5">
                        <HelpCircle className="w-4 h-4 text-cyan-400" />
                        <span className="font-bold text-xs text-white">
                          {language === 'hi' ? 'सत्यापन: क्या समस्या हल हुई?' : 'Verify Resolution:'}
                        </span>
                      </div>

                      {msg.verificationStatus === 'solved' ? (
                        <div className="flex items-center gap-1.5 text-xs font-bold text-green-400 py-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>
                            {language === 'hi' ? 'समाधान सत्यापित (समस्या हल)' : 'Verified: Problem Solved!'}
                          </span>
                        </div>
                      ) : msg.verificationStatus === 'unresolved' ? (
                        <div className="flex flex-col gap-2 py-1">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-400">
                            <AlertTriangle className="w-4 h-4" />
                            <span>
                              {language === 'hi'
                                ? 'समस्या अभी भी बनी हुई है'
                                : 'Issue Unresolved by Automated Steps'}
                            </span>
                          </div>
                          <button
                            onClick={() => setIsEscalationOpen(true)}
                            className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-900/30 active:scale-95 transition-all"
                          >
                            <Headphones className="w-3.5 h-3.5 text-cyan-300" />
                            <span>
                              {language === 'hi' ? 'सपोर्ट एजेंट से कनेक्ट करें' : 'Connect to Support Agent'}
                            </span>
                          </button>
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 gap-2 mt-1">
                          <button
                            onClick={() => handleProblemSolved(msg.id)}
                            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-green-500/20 hover:bg-green-500/30 text-green-300 border border-green-500/30 font-bold text-xs active:scale-95 transition-all"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />
                            <span>{language === 'hi' ? 'हाँ, हल हो गई' : 'Yes, problem solved'}</span>
                          </button>

                          <button
                            onClick={() => handleProblemStillExists(msg.id)}
                            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 font-bold text-xs active:scale-95 transition-all"
                          >
                            <XCircle className="w-3.5 h-3.5 text-red-400" />
                            <span>{language === 'hi' ? 'नहीं, अभी भी है' : 'No, problem still exists'}</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Message Footer */}
                  <div className="flex items-center justify-between gap-3 mt-2 pt-1 border-t border-white/5 text-[10px] text-neutral-400">
                    <div className="flex items-center gap-1">
                      <span>{msg.timestamp}</span>
                      {isUser && <CheckCheck className="w-3 h-3 text-cyan-300 inline ml-0.5" />}
                    </div>

                    {!isUser && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => copyToClipboard(msg.content, msg.id)}
                          className="hover:text-cyan-400 transition-colors p-0.5"
                          title="Copy steps"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3.5 h-3.5 text-green-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>

                        <button
                          onClick={() => toggleSpeech(msg.content, msg.id)}
                          className="hover:text-purple-400 transition-colors p-0.5"
                          title="Read instructions aloud"
                        >
                          {speakingId === msg.id ? (
                            <VolumeX className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-500 to-indigo-600 p-[1.5px] flex-shrink-0 mt-0.5 shadow-md">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                      alt="User"
                      className="w-full h-full rounded-[10px] object-cover"
                    />
                  </div>
                )}
              </div>
            );
          })}

          {/* Thinking animation */}
          {isLoading && (
            <div className="flex items-start gap-2.5 justify-start animate-in fade-in">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-400 to-purple-600 p-[1.5px] flex-shrink-0">
                <div className="w-full h-full bg-[#0a0b10] rounded-[10px] flex items-center justify-center">
                  <Wrench className="w-4 h-4 text-cyan-400 animate-spin" />
                </div>
              </div>
              <div className="bg-[#12141f] border border-white/10 rounded-2xl rounded-bl-none px-4 py-3 flex items-center gap-2 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-purple-400 animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-bounce [animation-delay:0.4s]" />
                <span className="text-xs text-neutral-400 ml-2 font-medium">
                  {attachedImage
                    ? language === 'hi'
                      ? 'Drixvid AI स्क्रीनशॉट का विज़ुअल विश्लेषण कर रहा है...'
                      : 'Drixvid AI is inspecting screenshot & error codes...'
                    : language === 'hi'
                    ? 'Drixvid समस्या निवारण विश्लेषण जारी...'
                    : 'Diagnosing Drixvid app issue...'}
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </main>

        {/* BOTTOM SECTION: PERMANENTLY FIXED DOCK */}
        <div className="flex-shrink-0 z-30 bg-[#0a0b12] border-t border-white/10 p-2.5 sm:p-3 pb-[max(0.625rem,env(safe-area-inset-bottom))] flex flex-col gap-2.5">
          {/* Attached Image Floating Preview (When an image is ready to be sent) */}
          {attachedImage && (
            <div className="p-2 rounded-2xl bg-[#141824] border border-cyan-500/40 shadow-xl flex items-center justify-between gap-3 animate-in fade-in zoom-in-95">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-black flex-shrink-0 border border-white/10">
                  <img
                    src={attachedImage.dataUrl}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white truncate">
                      {attachedImage.fileName || 'Screenshot ready to analyze'}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-400/20 text-cyan-300 font-bold">
                      Attached
                    </span>
                  </div>
                  <p className="text-[10px] text-cyan-400 flex items-center gap-1 mt-0.5">
                    <Sparkles className="w-3 h-3" />
                    <span>AI Vision will inspect visual error details & OCR codes</span>
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setAttachedImage(null)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-colors flex-shrink-0"
                title="Remove attachment"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Main Input Bar: Gallery Icon on Left, Text in Middle, Send/Voice on Right */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            {/* Pill container */}
            <div className="flex-1 flex items-center gap-1.5 px-2.5 py-1.5 rounded-3xl bg-[#141622] border border-white/10 focus-within:border-cyan-400/80 shadow-2xl transition-all">
              {/* Gallery button (directly opens gallery file selector in place of emoji) */}
              <button
                type="button"
                onClick={() => galleryInputRef.current?.click()}
                className="p-1.5 text-cyan-400 hover:text-cyan-300 active:scale-90 transition-all rounded-full hover:bg-cyan-500/10 flex-shrink-0"
                title={language === 'hi' ? 'गैलरी से स्क्रीनशॉट चुनें' : 'Attach screenshot from Gallery'}
              >
                <ImageIcon className="w-5 h-5 text-cyan-400" />
              </button>

              {/* Text input */}
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  attachedImage
                    ? language === 'hi'
                      ? 'स्क्रीनशॉट के साथ कुछ अतिरिक्त विवरण लिखें...'
                      : 'Add notes about this screenshot (optional)...'
                    : language === 'hi'
                    ? 'Message Drixvid AI (गैलरी से स्क्रीनशॉट भेजें)...'
                    : 'Message Drixvid AI (or send screenshot)...'
                }
                className="flex-1 bg-transparent py-2 text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none"
              />
            </div>

            {/* Share / Send Button (Matching user screenshot: Magenta-to-Purple Gradient with White Outline Paper Airplane) */}
            <button
              type="submit"
              disabled={isLoading}
              onClick={(e) => {
                if (!input.trim() && !attachedImage) {
                  e.preventDefault();
                  inputRef.current?.focus();
                }
              }}
              className="w-11 h-11 rounded-full bg-gradient-to-tr from-[#eb1478] via-[#b624be] to-[#7928ca] hover:brightness-110 active:scale-95 text-white flex items-center justify-center shadow-[0_4px_18px_rgba(235,20,120,0.4)] hover:shadow-[0_6px_22px_rgba(235,20,120,0.55)] transition-all flex-shrink-0 disabled:opacity-50"
              title={
                language === 'hi'
                  ? 'संदेश भेजें (Send Message)'
                  : 'Send message'
              }
            >
              {isLoading ? (
                <RefreshCw className="w-5 h-5 animate-spin text-white" />
              ) : (
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="w-[21px] h-[21px] text-white -translate-y-[0.5px] translate-x-[0.5px]"
                >
                  <path d="M22 2L15 22L11 13L2 9L22 2Z" />
                </svg>
              )}
            </button>
          </form>
        </div>


        {/* Diagnostic Modal */}
        <DiagnosticModal
          isOpen={isDiagnosticOpen}
          onClose={() => setIsDiagnosticOpen(false)}
          diagnosticConsent={diagnosticConsent}
          onToggleConsent={handleToggleConsent}
          language={language}
        />

        {/* Tickets Drawer */}
        <TicketsDrawer
          isOpen={isTicketsOpen}
          onClose={() => setIsTicketsOpen(false)}
          tickets={tickets}
          onRefreshTickets={refreshTickets}
          language={language}
        />

        {/* Escalation Modal */}
        <EscalationModal
          isOpen={isEscalationOpen}
          onClose={() => setIsEscalationOpen(false)}
          category={activeCategory}
          userDescription={caseDescription || input || (attachedImage ? 'Issue captured in screenshot.' : 'Unresolved technical issue in Drixvid app.')}
          attemptedSolutions={attemptedSteps}
          conversationSummary={messages.slice(-3).map((m) => `${m.role}: ${m.content}`).join('\n\n')}
          diagnosticConsent={diagnosticConsent}
          onTicketCreated={(ticket) => {
            refreshTickets();
            const ticketConfirmationMsg: ChatMessage = {
              id: `sys-${Date.now()}`,
              role: 'assistant',
              content:
                language === 'hi'
                  ? `🎫 **सपोर्ट टिकट बनाया गया: #${ticket.id}**\n- **स्थिति:** टिकट बनाया गया; human review की पुष्टि नहीं हुई\n- **ईमेल:** ${ticket.contactEmail || 'नहीं दिया गया'}\n\nईमेल भेजने के लिए तैयार Gmail ड्राफ्ट खोलें और Send दबाएँ। टिकट इस ब्राउज़र में सेव रहेगा।`
                  : `🎫 **Support Ticket Created: #${ticket.id}**\n- **Status:** Ticket saved; human review is not confirmed\n- **Email:** ${ticket.contactEmail || 'Not provided'}\n\nTo contact support, open the prepared email and press Send. Ticket persistence depends on the connected storage service.`,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              ticketId: ticket.id,
              category: activeCategory,
            };
            setMessages((prev) => [...prev, ticketConfirmationMsg]);
          }}
          language={language}
        />


        {/* Lightbox Modal (For viewing attached screenshots in full resolution) */}
        {lightboxImage && (
          <div
            onClick={() => setLightboxImage(null)}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out animate-in fade-in"
          >
            <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center">
              <button
                onClick={() => setLightboxImage(null)}
                className="absolute top-2 right-2 p-2 rounded-full bg-black/80 text-white hover:bg-black"
              >
                <X className="w-5 h-5" />
              </button>
              <img
                src={lightboxImage}
                alt="Enlarged screenshot"
                className="max-h-[85vh] max-w-full rounded-2xl object-contain shadow-2xl border border-white/10"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Markdown formatting helper
function renderFormattedContent(content: string) {
  if (content.includes('```')) {
    const parts = content.split(/(```[\s\S]*?```)/g);
    return parts.map((part, i) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const lines = part.slice(3, -3).trim().split('\n');
        const lang = lines[0].trim();
        const code = (lang ? lines.slice(1) : lines).join('\n');
        return (
          <div
            key={i}
            className="my-2.5 rounded-xl bg-black/70 border border-white/10 p-3 font-mono text-[11px] overflow-x-auto text-cyan-300"
          >
            {lang && (
              <div className="text-[10px] uppercase text-neutral-500 mb-1 font-bold tracking-wider">
                {lang}
              </div>
            )}
            <pre className="whitespace-pre">{code}</pre>
          </div>
        );
      }
      return <span key={i}>{formatText(part)}</span>;
    });
  }
  return formatText(content);
}

function formatText(text: string) {
  const boldParts = text.split(/(\*\*.*?\*\*)/g);
  return boldParts.map((bp, j) => {
    if (bp.startsWith('**') && bp.endsWith('**')) {
      return (
        <strong key={j} className="text-white font-bold">
          {bp.slice(2, -2)}
        </strong>
      );
    }
    return bp;
  });
}
