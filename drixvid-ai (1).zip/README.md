# Drixvid Support AI

A React + Express support assistant prepared against the supplied Drixvid source project. It includes a server-side OpenAI Responses API integration, optional Gemini integration, screenshot input handling, a source-derived support knowledge base, and an offline fallback that does not pretend to have live AI or screenshot vision.

## Run locally

1. Install Node.js 22 LTS or another version supported by the project dependencies.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add a valid OpenAI Platform API key to `OPENAI_API_KEY` on the **server only**. The default `OPENAI_MODEL=gpt-4.1` must be available to your API project. Alternatively configure `GEMINI_API_KEY` for Gemini fallback when OpenAI is not configured.
5. Run `npm run dev` and open the local URL printed in the terminal.
6. Open `/api/ai/status` to inspect configuration, then send a real text message and a screenshot in the app. A configured key is not proof of successful API connectivity.

## What is implemented

- OpenAI Responses API call from the Express server; API keys are not shipped to browser code.
- Optional Gemini provider when OpenAI is not configured.
- Text conversation history and PNG/JPEG/WEBP screenshot input with MIME and size checks.
- Server-side request timeout, per-IP in-memory rate limiting, input validation, and provider-aware error messages.
- Source-derived support knowledge about Firebase Authentication, Firestore profile sync, video/feed, Creator Studio upload, channels/social features, settings, admin security, AI configuration, and support tickets. Retrieved facts are injected into the AI instructions.
- Offline fallback provides conservative guidance and explicitly says it cannot perform live AI or screenshot analysis.
- Diagnostics only report what the server/browser can actually observe; CDN, payments, and external service health are not fabricated.
- User feedback is not treated as verified training data. Public users cannot modify the knowledge base.
- Ticket UI creates a ticket record and a Gmail compose draft. Email is **not** sent automatically.
- Public server ticket listing and Firestore ticket writes are disabled until authenticated owner-scoped access rules are implemented. Browser-local tickets remain available in that browser.

## Important limits before production

- A real API key, enabled model, active quota/billing, and network access are required for live AI answers and vision analysis. No credentials are bundled in this ZIP.
- The dependency install/build and a live API call could not be verified in the current environment because package installation timed out and no API key was available. Do not treat the project as production-verified until `npm install`, `npm run build`, `npm run lint`, and real API tests succeed.
- Ticket records in the server are in-memory and may disappear on restart; browser-local tickets persist only in that browser. Configure authenticated, per-user database storage before production.
- The included Firestore rules deny access by default. Do not loosen them to make the UI appear to work; implement authenticated user ownership first.
- The rate limiter is per-process. Multi-instance deployments need a shared limiter, plus authentication, abuse controls, monitoring, retention/deletion policies, and security review.
- No AI can be guaranteed to outperform ChatGPT or Gemini in every task. The intended advantage is accurate, source-grounded Drixvid support, with clear uncertainty and verified documentation.
